# -*- coding: utf-8 -*-
"""
One-click end-to-end pipeline for PyCharm: data generation -> training ->
evaluation -> emergency scheduling -> baselines -> ablation.

Full configuration (paper):   python run_all.py
Smoke test (minutes on CPU):  python run_all.py --quick
Custom:                       python run_all.py --nodes 50 --hours 10000
                                                        --epochs 100
"""
from __future__ import division

import argparse
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.join(ROOT, "scripts")


def run_script(name, extra=None):
    cmd = [sys.executable, os.path.join(SCRIPTS, name)]
    if extra:
        cmd += extra
    print("\n" + "=" * 70)
    print(">>> Running %s" % name)
    print("=" * 70)
    rc = subprocess.call(cmd, cwd=ROOT)
    if rc != 0:
        print("!!! %s failed with exit code %d" % (name, rc))
        sys.exit(rc)
    return rc


def main():
    ap = argparse.ArgumentParser(description="End-to-end replication pipeline")
    ap.add_argument("--quick", action="store_true",
                    help="smoke test: 16 nodes / 1000 h / 2 epochs")
    ap.add_argument("--nodes", type=int, default=None)
    ap.add_argument("--hours", type=int, default=None)
    ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--baseline_epochs", type=int, default=None)
    ap.add_argument("--skip_baselines", action="store_true")
    ap.add_argument("--skip_ablation", action="store_true")
    args = ap.parse_args()

    nodes = args.nodes
    hours = args.hours
    epochs = args.epochs
    bl_epochs = args.baseline_epochs
    if args.quick:
        nodes = nodes or 16
        hours = hours or 1000
        epochs = epochs or 2
        bl_epochs = bl_epochs or 1

    data_args = []
    if nodes:
        data_args += ["--nodes", str(nodes)]
    if hours:
        data_args += ["--hours", str(hours)]

    run_script("01_generate_data.py", data_args)

    train_args = []
    if epochs:
        train_args += ["--epochs", str(epochs)]
    run_script("02_train_tft_stgnn.py", train_args)
    run_script("03_evaluate.py")
    run_script("04_optimize_schedule.py")

    if not args.skip_baselines:
        bl_args = []
        if bl_epochs:
            bl_args += ["--epochs", str(bl_epochs)]
        run_script("05_run_baselines.py", bl_args)

    if not args.skip_ablation:
        ab_args = ["--epochs", str(epochs if epochs else 20)]
        run_script("06_ablation.py", ab_args)

    print("\n" + "=" * 70)
    print(">>> Pipeline finished. Outputs under data/ and outputs/")
    print("=" * 70)


if __name__ == "__main__":
    main()
