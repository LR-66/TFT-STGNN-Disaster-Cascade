# -*- coding: utf-8 -*-
"""
Preprocessing and standardization (Section 2.1 / 3.1).

Implements, per the paper:

  * **Detrending** of continuous meteorological sequences (removes the linear
    trend of every (node, feature) channel);
  * **Log-stabilization** of right-skewed variables (rainfall and all discrete
    public-opinion indicators) to compress distribution skewness;
  * **Sliding-window standardization** along the time axis -> zero mean /
    unit variance within a 168 h window;
  * **Z-score standardization grouped by region type** to preserve local
    statistical features (upstream / midstream / downstream).

The fitted statistics are stored so that the validation / test splits are
transformed with training-derived statistics only (no information leakage).
"""
from __future__ import division

import numpy as np

from config import config as C

# features that receive log-stabilization (right-skewed per Table 1)
LOG_FEATURES = {"rainfall", "wind_speed", "disaster_keyword_freq",
                "help_requests", "traffic_incidents"}


class Preprocessor(object):
    """Fit on the training split, then transform any split."""

    def __init__(self, window_std=None, log_stabilize=None, detrend=None,
                 group_by_region=None):
        pp = C.PREPROCESS
        self.window_std = window_std if window_std is not None else \
            pp["window_std"]
        self.log_stabilize = log_stabilize if log_stabilize is not None else \
            pp["log_stabilize"]
        self.detrend = detrend if detrend is not None else pp["detrend"]
        self.group_by_region = group_by_region if group_by_region is not None \
            else pp["group_by_region"]

        self.slope_ = None
        self.intercept_ = None
        self.group_mean_ = None
        self.group_std_ = None
        self.region_type_ = None

    # ---------------------------------------------------------------- #
    @staticmethod
    def _detrend(x):
        """Remove per-channel linear trend; x: (T, N, C)."""
        t = np.arange(x.shape[0], dtype=np.float64)
        t = (t - t.mean()) / (t.std() + 1e-6)
        slope = np.einsum("t,tnc->nc", t, x) / np.einsum("t,t->", t, t)
        intercept = x.mean(axis=0, keepdims=True)
        return x - slope[None, :, :] * t[:, None, None] - intercept, slope, \
            intercept

    @staticmethod
    def _sliding_standardize(x, window):
        """Rolling z-score with centred window along the time axis."""
        t, n, c = x.shape
        mu = np.empty_like(x)
        sd = np.empty_like(x)
        half = window // 2
        for i in range(t):
            lo, hi = max(0, i - half), min(t, i + half + 1)
            seg = x[lo:hi]
            mu[i] = seg.mean(axis=0)
            sd[i] = seg.std(axis=0)
        return (x - mu) / (sd + 1e-6)

    # ---------------------------------------------------------------- #
    def fit(self, x, region_type):
        """
        x          : (T, N, C) raw covariates
        region_type: (N,) int array 0/1/2
        """
        self.region_type_ = region_type
        if self.detrend:
            x, self.slope_, self.intercept_ = self._detrend(x)
        if self.log_stabilize:
            x = np.log1p(np.clip(x, 0, None))
        x = self._sliding_standardize(x, self.window_std)
        if self.group_by_region:
            g_mean = np.zeros(3)
            g_std = np.zeros(3)
            for g in range(3):
                mask = region_type == g
                if mask.any():
                    g_mean[g] = x[:, mask].mean()
                    g_std[g] = x[:, mask].std()
            self.group_mean_ = g_mean
            self.group_std_ = g_std
        return x

    def transform(self, x, region_type=None):
        """Apply the fitted pipeline to new data (validation/test)."""
        if self.detrend:
            t = np.arange(x.shape[0], dtype=np.float64)
            t = (t - t.mean()) / (t.std() + 1e-6)
            x = x - self.slope_[None, :, :] * t[:, None, None] - \
                self.intercept_
        if self.log_stabilize:
            x = np.log1p(np.clip(x, 0, None))
        x = self._sliding_standardize(x, self.window_std)
        if self.group_by_region and self.group_mean_ is not None:
            rt = region_type if region_type is not None else self.region_type_
            for g in range(3):
                mask = rt == g
                if mask.any():
                    x[:, mask] = (x[:, mask] - self.group_mean_[g]) / \
                                 (self.group_std_[g] + 1e-6)
        return x

    def fit_transform(self, x, region_type):
        return self.fit(x, region_type)


def apply_preprocessing(x, region_type):
    """Convenience wrapper: fit on training split and return processed array."""
    pp = Preprocessor()
    return pp.fit(x, region_type), pp
