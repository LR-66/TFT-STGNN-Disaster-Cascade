# -*- coding: utf-8 -*-
"""
PyTorch dataset / dataloader construction (Section 3.1 / 3.2).

Sliding-window samples: given the past `lookback` hours of multi-source
covariates of all regions, predict the average RIRI of the next `horizon`
hours (24h-ahead, as in the paper's retrospective validation). The
train/validation/test split is chronological with the paper's ratio
70 % / 15 % / 15 % (split seed 123).

The full standardized tensor stays in memory and windows are sliced on the
fly, so even 500-node / 10 000-hour datasets fit in a few hundred MB.
"""
from __future__ import division

import numpy as np
import torch
from torch.utils.data import Dataset

from config import config as C


def split_indices(T, val_frac=None, test_frac=None):
    """Chronological split boundaries; returns (train, val, test) index arrays."""
    val_frac = val_frac if val_frac is not None else C.PREPROCESS["val_frac"]
    test_frac = test_frac if test_frac is not None else C.PREPROCESS["test_frac"]
    n_val = int(T * val_frac)
    n_test = int(T * test_frac)
    n_train = T - n_val - n_test
    train = np.arange(0, n_train)
    val = np.arange(n_train, n_train + n_val)
    test = np.arange(n_train + n_val, T)
    return train, val, test


class CascadeDataset(Dataset):
    """
    Parameters
    ----------
    x       : (T, N, C) preprocessed covariates
    y       : (T, N) RIRI target
    static  : (N, D_s) standardized static matrix
    adj     : (N, N) geographic adjacency (float weights)
    indices : absolute time indices allowed for this split
    lookback: input window length (hours)
    horizon : prediction horizon (hours)
    """

    def __init__(self, x, y, static, adj, indices, lookback=None,
                 horizon=None):
        self.x = x
        self.y = y
        self.static = static
        self.adj = adj
        self.indices = np.asarray(indices)
        self.lookback = lookback if lookback is not None else 24
        self.horizon = horizon if horizon is not None else C.SIM["horizon"]

    def __len__(self):
        return max(0, len(self.indices) - self.lookback - self.horizon + 1)

    def __getitem__(self, i):
        t = int(self.indices[i + self.lookback])
        x_win = self.x[t - self.lookback:t]              # (lookback, N, C)
        y_fut = self.y[t + 1:t + 1 + self.horizon]       # (horizon, N)
        y_t = y_fut.mean(axis=0)                         # (N,)
        return (x_win.astype(np.float32), self.static.astype(np.float32),
                self.adj.astype(np.float32), y_t.astype(np.float32))


def cascade_collate(batch):
    """Stack batch items into model tensors (custom collate for efficiency)."""
    x = torch.from_numpy(np.stack([b[0] for b in batch]))       # (B,T,N,C)
    s = torch.from_numpy(batch[0][1])                            # (N,D_s)
    a = torch.from_numpy(batch[0][2])                            # (N,N)
    y = torch.from_numpy(np.stack([b[3] for b in batch]))        # (B,N)
    return x, s, a, y


def build_loaders(x, y, static, adj, batch_size=None, num_workers=0,
                  shuffle_seed=None):
    """
    Build (train_loader, val_loader, test_loader) with the 70/15/15 split.
    The val/test loaders are always ordered (no shuffle).
    """
    batch_size = batch_size if batch_size is not None else C.TRAIN["batch_size"]
    shuffle_seed = shuffle_seed if shuffle_seed is not None else C.SEED_SPLIT

    T = x.shape[0]
    tr, va, te = split_indices(T)
    tr_ds = CascadeDataset(x, y, static, adj, tr)
    va_ds = CascadeDataset(x, y, static, adj, va)
    te_ds = CascadeDataset(x, y, static, adj, te)

    g = torch.Generator()
    g.manual_seed(shuffle_seed)

    train_loader = torch.utils.data.DataLoader(
        tr_ds, batch_size=batch_size, shuffle=True, generator=g,
        num_workers=num_workers, collate_fn=cascade_collate)
    val_loader = torch.utils.data.DataLoader(
        va_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, collate_fn=cascade_collate)
    test_loader = torch.utils.data.DataLoader(
        te_ds, batch_size=batch_size, shuffle=False,
        num_workers=num_workers, collate_fn=cascade_collate)
    return train_loader, val_loader, test_loader
