# -*- coding: utf-8 -*-
"""
Temporal Fusion Transformer module (Section 2.1 - 2.2, Eq. 1 - 7).

Components implemented exactly as described in the paper:

  * Gated Residual Network (GRN, Eq. 1): adaptive gating between the input and
    a non-linear transform branch + residual path + layer normalization;
  * Variable Selection Network (Eq. 2 - 3): context-aware softmax weights over
    feature channels that evolve with the disaster stage;
  * Static attribute modulation: conditional gating — static region attributes
    are linearly projected into scale / shift vectors modulating the dynamic
    representation (enhanced static attribute modulation of Section 2.1);
  * Multi-head self-attention with causal masking (Eq. 4 - 5): future
    positions are masked to negative infinity so no information leaks;
  * Causal convolution (Eq. 6): unidirectional padding, captures high
    frequency local fluctuation without violating temporal causality.

The original TFT decoder is removed on purpose (Section 2.1, adaptation 3):
the encoder's state vector is directly fed into the spatiotemporal fusion
layer, transferring prediction uncertainty to the decision module.
"""
from __future__ import division

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import config as C


def quantile_loss(y_true, y_pred, quantiles=None):
    """
    Asymmetric quantile loss (Eq. 7).

    L = mean over quantiles of max(q * (y - y_hat), (q - 1) * (y - y_hat))
    """
    if quantiles is None:
        quantiles = C.TFT["quantiles"]
    qs = torch.as_tensor(quantiles, dtype=y_pred.dtype,
                         device=y_pred.device).view(1, 1, -1)
    # y_true: (B, N) -> (B, N, 1); y_pred: (B, N, Q); broadcast -> (B, N, Q)
    err = y_true.unsqueeze(-1) - y_pred
    loss = torch.max(qs * err, (qs - 1.0) * err)           # (B, N, Q)
    return loss.mean()


class GRN(nn.Module):
    """Gated Residual Network (Eq. 1)."""

    def __init__(self, d_in, d_out=None, d_hidden=128, dropout=0.1):
        super(GRN, self).__init__()
        d_out = d_out or d_in
        self.linear1 = nn.Linear(d_in, d_hidden)
        self.linear2 = nn.Linear(d_hidden, d_out)
        self.gate = nn.Linear(d_in, d_out)                 # sigmoid gate
        self.skip = nn.Linear(d_in, d_out) if d_in != d_out else nn.Identity()
        self.layernorm = nn.LayerNorm(d_out)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        # x: (..., d_in)
        h = F.elu(self.linear1(x))
        h = self.dropout(self.linear2(h))
        g = torch.sigmoid(self.gate(x))                    # gate weight
        out = g * h + (1.0 - g) * self.skip(x)             # adaptive weighting
        return self.layernorm(out)


class VariableSelectionNetwork(nn.Module):
    """
    Variable selection (Eq. 2 - 3) with static-attribute conditional gating
    (Section 2.1 adaptation 1).

    Inputs
    ------
    x      : (B, T, C) flattened covariates
    static : (B, T, D_s) static attributes broadcast along time, or None

    Returns
    -------
    out  : (B, T, d) weighted, context-aware representation
    w    : (B, T, C) feature importance weights (for interpretability)
    """

    def __init__(self, d_in, d_hidden=128, n_static=7, dropout=0.1):
        super(VariableSelectionNetwork, self).__init__()
        self.d_in = d_in
        self.d_hidden = d_hidden
        # per-feature GRN: input channel -> hidden
        self.feature_grns = nn.ModuleList(
            [GRN(1, d_hidden, d_hidden, dropout) for _ in range(d_in)])
        # context encoder: summarises the temporal context vector c (Eq. 2)
        self.context_grn = GRN(d_hidden, d_in, d_hidden, dropout)
        self.softmax = nn.Softmax(dim=-1)
        # static modulation: scale & shift per feature dimension
        self.static_scale = nn.Linear(n_static, d_in * d_hidden)
        self.static_shift = nn.Linear(n_static, d_in * d_hidden)

    def forward(self, x, static=None):
        # x: (B, T, C); static: (B, D_s) (no time dimension — static
        # attributes are time-invariant, so modulation is computed once and
        # broadcast along the time axis)
        b, t, c = x.size()
        feats = []
        for i in range(c):
            feats.append(self.feature_grns[i](x[..., i:i + 1]))   # (B,T,d)
        feats = torch.stack(feats, dim=2)                         # (B,T,C,d)

        if static is not None:
            # static modulation vector applied as scale & shift (conditional
            # gated modulation of Section 2.1), broadcast over time
            scale = self.static_scale(static).view(b, c, self.d_hidden)
            shift = self.static_shift(static).view(b, c, self.d_hidden)
            feats = feats * (1.0 + scale.unsqueeze(1)) + shift.unsqueeze(1)

        # context vector: mean pooling over time (temporal context encoding c)
        ctx = feats.mean(dim=1)                                   # (B,C,d)
        w_logits = self.context_grn(ctx)                          # (B, C, d)
        w = self.softmax(w_logits.mean(dim=-1))                   # (B, C)
        w = w.unsqueeze(1).unsqueeze(-1)                          # (B,1,C,1)
        out = (feats * w).sum(dim=2)                              # (B,T,d)
        return out, w.squeeze(-1).squeeze(1)                      # out,(B,C)


class CausalConv1d(nn.Module):
    """Causal 1-D convolution (Eq. 6): unidirectional padding, same length."""

    def __init__(self, d_model, kernel=3, dilation=1):
        super(CausalConv1d, self).__init__()
        self.pad = (kernel - 1) * dilation
        self.conv = nn.Conv1d(d_model, d_model, kernel_size=kernel,
                              dilation=dilation)

    def forward(self, x):
        # x: (B, T, d) -> (B, d, T) -> causal pad -> conv -> back
        x = x.transpose(1, 2)
        x = F.pad(x, (self.pad, 0))
        x = self.conv(x)
        return x.transpose(1, 2)


class TFTEncoder(nn.Module):
    """
    Full TFT encoder: variable selection -> GRN -> multi-head causal
    self-attention -> causal convolution, with static modulation.

    Inputs
    ------
    x      : (B, T, N, C) dynamic covariates
    static : (N, D_s) standardized static attributes

    Returns
    -------
    state     : (B, N, d) per-node temporal state (last time step)
    context   : (B, d) global temporal context vector (used by ST-GNN
                fusion coefficient, Eq. 9)
    attn_weights : (B*N, heads, T, T) for the interpretability figure
    var_weights  : (B*N, C) variable-selection weights
    """

    def __init__(self, d_in=None, d_hidden=None, n_heads=None, n_static=7,
                 n_layers=2, dropout=0.1, causal_kernel=3):
        super(TFTEncoder, self).__init__()
        cfg = C.TFT
        self.d_in = d_in if d_in is not None else len(C.DYNAMIC_FEATURES)
        self.d_hidden = d_hidden if d_hidden is not None else cfg["hidden_size"]
        self.n_heads = n_heads if n_heads is not None else cfg["num_heads"]
        self.n_layers = n_layers if n_layers is not None else cfg["num_layers"]

        self.input_proj = nn.Linear(self.d_in, self.d_hidden)
        self.vsn = VariableSelectionNetwork(self.d_in, self.d_hidden,
                                            n_static, dropout)

        attn = nn.MultiheadAttention(self.d_hidden, self.n_heads,
                                     dropout=dropout, batch_first=True)
        self.attn = nn.ModuleList([attn for _ in range(self.n_layers)])
        self.attn_grn = nn.ModuleList(
            [GRN(self.d_hidden, self.d_hidden, self.d_hidden, dropout)
             for _ in range(self.n_layers)])
        self.convs = nn.ModuleList(
            [CausalConv1d(self.d_hidden, causal_kernel) for _ in
             range(self.n_layers)])
        self.conv_grn = nn.ModuleList(
            [GRN(self.d_hidden, self.d_hidden, self.d_hidden, dropout)
             for _ in range(self.n_layers)])
        # collect attention weights only when requested (visualization);
        # keeping it off makes training faster and saves memory
        self.collect_attn = False

    @staticmethod
    def _causal_mask(t):
        """Upper-triangular mask (Eq. 4): future -> -inf."""
        return torch.triu(torch.full((t, t), float("-inf")), diagonal=1)

    def forward(self, x, static):
        b, t, n, c = x.size()
        x = x.permute(0, 2, 1, 3).reshape(b * n, t, c)   # (B*N, T, C)
        # static attributes are time-invariant: repeat over the batch dim
        s = static.repeat(b, 1, 1).reshape(b * n, -1)    # (B*N, D_s)

        # variable selection with static modulation
        z, var_w = self.vsn(x, s)                          # (B*N, T, d)

        mask = self._causal_mask(t).to(z.device)
        attn_weights = []
        for i in range(self.n_layers):
            z, w = self.attn[i](z, z, z, attn_mask=mask,
                                need_weights=self.collect_attn)
            if self.collect_attn:
                attn_weights.append(w.detach())
            z = self.attn_grn[i](z)
            z = self.conv_grn[i](self.convs[i](z))

        state = z[:, -1, :]                                # (B*N, d)
        state = state.view(b, n, self.d_hidden)            # (B, N, d)
        context = z.mean(dim=1).view(b, n, self.d_hidden).mean(dim=1)  # (B, d)

        cat_w = torch.cat([xw.reshape(-1, t, t)[:, -1:] for xw in attn_weights],
                          dim=1) if attn_weights else None
        return state, context, cat_w, var_w.view(b, n, c)
