# -*- coding: utf-8 -*-
"""
Joint TFT-ST-GNN model (Section 2.4, Eq. 13).

Pipeline:
    1. TFTEncoder produces per-node temporal states (B, N, d) and a global
       context vector (B, d);
    2. STGNN produces spatial node embeddings (B, N, d) with task-adapted
       hybrid adjacency;
    3. Spatiotemporal fusion (Eq. 13) — gated bilinear fusion:
         * non-linear interaction branch: Hadamard product of the
           concatenation-driven interaction features + ReLU;
         * dynamic gating branch: sigmoid gate suppressing noise dimensions;
         * residual connection with the original spliced features;
    4. Quantile head outputs P10 / P50 / P90 risk intensity per node,
       trained with the asymmetric quantile loss (Eq. 7).

The three alignment mechanisms of Section 2.4 are respected: shared node
indices and hourly timestamps, equal hidden dims (128), and end-to-end joint
gradient flow to both modules.
"""
from __future__ import division

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import config as C
from src.models.tft import TFTEncoder, quantile_loss
from src.models.stgnn import STGNN


class GatedBilinearFusion(nn.Module):
    """Eq. (13): gated bilinear fusion of temporal and spatial features."""

    def __init__(self, d_in, d_out=64, dropout=0.1):
        super(GatedBilinearFusion, self).__init__()
        self.gate_linear = nn.Linear(2 * d_in, d_out)        # W_g
        self.interact_linear = nn.Linear(d_in, d_out)        # W_i (per branch)
        self.proj = nn.Linear(d_in, d_out)                   # W_l linear path
        self.gate_s = nn.Linear(d_out, d_out)
        self.dropout = nn.Dropout(dropout)

    def forward(self, h_t, h_s):
        # h_t, h_s: (B, N, d)
        cat = torch.cat([h_t, h_s], dim=-1)                  # (B, N, 2d)
        # non-linear interaction branch (Hadamard coupling + ReLU)
        inter = self.interact_linear(h_t) * self.interact_linear(h_s)
        inter = F.relu(inter)
        # dynamic gating branch
        gate = torch.sigmoid(self.gate_s(self.gate_linear(cat)))
        # residual connection with original spliced features
        resid = self.proj(h_t + h_s)
        out = self.dropout(gate * inter) + resid
        return out


class TFTSTGNN(nn.Module):
    """Full joint model: TFT + ST-GNN + gated bilinear fusion + quantiles."""

    def __init__(self, n_nodes, d_in=None, d_hidden=None, quantiles=None,
                 n_static=7):
        super(TFTSTGNN, self).__init__()
        cfg_t = C.TFT
        self.d_hidden = d_hidden if d_hidden is not None else cfg_t["hidden_size"]
        self.quantiles = quantiles if quantiles is not None else \
            cfg_t["quantiles"]

        self.tft = TFTEncoder(d_in=d_in, d_hidden=self.d_hidden,
                              n_heads=cfg_t["num_heads"], n_static=n_static,
                              n_layers=cfg_t["num_layers"],
                              causal_kernel=cfg_t["causal_conv_kernel"])
        self.stgnn = STGNN(n_nodes, d_hidden=self.d_hidden)
        self.fusion = GatedBilinearFusion(self.d_hidden, self.d_hidden)
        self.head = nn.Linear(self.d_hidden, len(self.quantiles))

    def forward(self, x, static, adj_geo):
        """
        x      : (B, T, N, C) covariates
        static : (N, D_s) static matrix
        adj_geo: (N, N) geographic adjacency
        Returns dict: pred (B, N, Q), context (B, d), lambda_t (B,),
                      attn_w, var_w (interpretability outputs)
        """
        h_t, context, attn_w, var_w = self.tft(x, static)
        h_s, lam = self.stgnn(h_t, context, adj_geo)
        fused = self.fusion(h_t, h_s)                         # (B, N, d)
        pred = self.head(fused)                               # (B, N, Q)
        return dict(pred=pred, context=context, lambda_t=lam,
                    attn_w=attn_w, var_w=var_w)

    def loss(self, batch):
        """Training loss on a batch: quantile loss (Eq. 7)."""
        x, static, adj, y = batch
        out = self.forward(x, static, adj)
        return quantile_loss(y, out["pred"], self.quantiles)
