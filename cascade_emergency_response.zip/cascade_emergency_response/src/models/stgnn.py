# -*- coding: utf-8 -*-
"""
Spatio-Temporal Graph Neural Network (Section 2.3, Eq. 8 - 11).

  * Task-adapted dynamic adjacency (Eq. 8):
        A_adapt = Softmax(ReLU(E1 @ E2^T))
    with learnable node embeddings E1, E2 re-estimating implicit connections;
  * Hybrid topology fusion (Eq. 9):
        A_t = (1 - lambda_t) * A_geo + lambda_t * A_adapt
    where lambda_t in (0,1) is generated from the TFT temporal context vector
    through a small MLP + sigmoid — the model dynamically shifts trust
    between the static geographic graph and the data-driven topology;
  * Graph convolution (Eq. 10): two GCN layers on the symmetric-normalised
    hybrid adjacency (the paper's optimal balance of propagation depth vs.
    gradient stability);
  * Time-aware gating unit (Eq. 11): GRU-style update gate on the node state,
    with the first-step hidden state initialised as a linear projection of the
    TFT output (global context guidance).
"""
from __future__ import division

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from config import config as C


class AdaptiveAdjacency(nn.Module):
    """Learnable dynamic adjacency (Eq. 8)."""

    def __init__(self, n_nodes, emb_dim=32):
        super(AdaptiveAdjacency, self).__init__()
        self.emb1 = nn.Parameter(torch.empty(n_nodes, emb_dim))
        self.emb2 = nn.Parameter(torch.empty(n_nodes, emb_dim))
        nn.init.xavier_uniform_(self.emb1)
        nn.init.xavier_uniform_(self.emb2)

    def forward(self):
        a = torch.relu(torch.mm(self.emb1, self.emb2.t()))
        a = a - a.min(dim=1, keepdim=True).values
        return F.softmax(a, dim=1)                       # row-normalised


class GCNLayer(nn.Module):
    """Single graph-convolution layer (Eq. 10, Kipf & Welling style)."""

    def __init__(self, d_in, d_out, dropout=0.1):
        super(GCNLayer, self).__init__()
        self.linear = nn.Linear(d_in, d_out)
        self.dropout = nn.Dropout(dropout)

    @staticmethod
    def _normalise(a):
        """Symmetric normalisation D^-1/2 A D^-1/2 with self-loops.
        Supports both (N, N) and batched (B, N, N) adjacency."""
        if a.dim() == 3:
            b, n = a.size(0), a.size(1)
            a = a + torch.eye(n, device=a.device)
            deg = a.sum(dim=-1)
            dinv = torch.pow(deg + 1e-6, -0.5)
            d_mat = torch.diag_embed(dinv)
            return d_mat @ a @ d_mat.transpose(-1, -2)
        n = a.size(0)
        a = a + torch.eye(n, device=a.device)
        deg = a.sum(dim=1)
        dinv = torch.pow(deg + 1e-6, -0.5)
        d_mat = torch.diag(dinv)
        return d_mat @ a @ d_mat

    def forward(self, h, a):
        # h: (B, N, d_in); a: (N, N) or (B, N, N)
        a_norm = self._normalise(a)
        h = torch.einsum("bij,bjd->bid", a_norm, h)
        h = self.linear(h)
        return F.relu(self.dropout(h))


class STGNN(nn.Module):
    """
    ST-GNN module.

    Inputs
    ------
    h_temporal : (B, N, d) TFT temporal states (first-step initialisation)
    context    : (B, d) TFT global context (fusion coefficient, Eq. 9)
    adj_geo    : (N, N) geographic adjacency weights

    Returns
    -------
    h_out    : (B, N, d) spatial node embeddings
    lambda_t : (B,) time-dependent fusion weight (for interpretability)
    """

    def __init__(self, n_nodes, d_hidden=None, n_layers=None,
                 emb_dim=None, init_adaptive_weight=None):
        super(STGNN, self).__init__()
        cfg = C.STGNN
        self.d_hidden = d_hidden if d_hidden is not None else cfg["hidden_size"]
        self.n_layers = n_layers if n_layers is not None else \
            cfg["graph_conv_layers"]
        emb_dim = emb_dim if emb_dim is not None else cfg["emb_dim"]
        init_w = init_adaptive_weight if init_adaptive_weight is not None \
            else cfg["init_adaptive_weight"]

        self.adj_net = AdaptiveAdjacency(n_nodes, emb_dim)
        self.init_proj = nn.Linear(self.d_hidden, self.d_hidden)
        self.convs = nn.ModuleList(
            [GCNLayer(self.d_hidden, self.d_hidden) for _ in
             range(self.n_layers)])
        # time-aware gating (Eq. 11)
        self.gate = nn.Linear(2 * self.d_hidden, self.d_hidden)
        # fusion coefficient MLP (Eq. 9)
        self.fusion = nn.Sequential(
            nn.Linear(self.d_hidden, 16), nn.ReLU(),
            nn.Linear(16, 1), nn.Sigmoid())
        self._init_w = init_w

    def forward(self, h_temporal, context, adj_geo):
        b, n, d = h_temporal.size()
        # initial hidden state: linear projection of TFT output (Section 2.3)
        h = self.init_proj(h_temporal)                        # (B, N, d)

        a_adapt = self.adj_net()                              # (N, N)
        # time-dependent fusion weight from the TFT context vector (Eq. 9)
        lam = self.fusion(context)                            # (B, 1)
        lam = lam.unsqueeze(-1)                               # (B, 1, 1)
        a_hybrid = (1.0 - lam) * adj_geo.unsqueeze(0) + lam * a_adapt
        # spectral-radius control: row normalize the hybrid matrix
        row_sum = a_hybrid.sum(dim=2, keepdim=True) + 1e-6
        a_hybrid = a_hybrid / row_sum

        h_prev = h
        for i in range(self.n_layers):
            h_new = self.convs[i](h_prev, a_hybrid)             # (B,N,d)
            # time-aware gating (Eq. 11): gate depends on previous + current
            g = torch.sigmoid(self.gate(torch.cat([h_prev, h_new], dim=-1)))
            h = g * h_new + (1.0 - g) * h_prev
            h_prev = h

        return h, lam.squeeze(-1)
