# -*- coding: utf-8 -*-
"""Baselines package (data-availability item 7)."""
