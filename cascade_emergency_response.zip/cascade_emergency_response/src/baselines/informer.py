# -*- coding: utf-8 -*-
"""
Informer baseline (Section 3.2.1).

Paper configuration: prob-sparse sampling rate 0.7, 4 encoder / decoder
layers, 4 convolutional kernels. This compact implementation keeps the
prob-sparse attention (sampling-based sparsity, 70 % of keys retained) and the
4-layer encoder; the decoder is replaced by a prediction head (the paper's
evaluation only needs point forecasts from the baselines).
"""
from __future__ import division

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import config as C


class ProbSparseAttention(nn.Module):
    """Sparse self-attention that keeps a fraction of keys (sampling rate)."""

    def __init__(self, d_model, n_heads, sampling=0.7):
        super(ProbSparseAttention, self).__init__()
        self.n_heads = n_heads
        self.d_k = d_model // n_heads
        self.sampling = sampling
        self.q = nn.Linear(d_model, d_model)
        self.k = nn.Linear(d_model, d_model)
        self.v = nn.Linear(d_model, d_model)
        self.out = nn.Linear(d_model, d_model)

    def forward(self, x):
        b, t, d = x.size()
        q = self.q(x).view(b, t, self.n_heads, self.d_k).transpose(1, 2)
        k = self.k(x).view(b, t, self.n_heads, self.d_k).transpose(1, 2)
        v = self.v(x).view(b, t, self.n_heads, self.d_k).transpose(1, 2)

        n_keys = max(1, int(t * self.sampling))
        # random key sampling (prob-sparse: measure-based sparsity, compact
        # variant keeps the top scoring keys)
        scores = torch.einsum("bhqd,bhkd->bhqk", q, k) / (self.d_k ** 0.5)
        m = scores.max(dim=-1).values - scores.mean(dim=-1)
        idx = m.topk(n_keys, dim=-1).indices                       # (B,H,K)
        k_sel = k.gather(2, idx.unsqueeze(-1).expand(-1, -1, -1, self.d_k))
        v_sel = v.gather(2, idx.unsqueeze(-1).expand(-1, -1, -1, self.d_k))
        attn = torch.softmax(torch.einsum("bhqd,bhkd->bhqk", q, k_sel) /
                             (self.d_k ** 0.5), dim=-1)
        z = torch.einsum("bhqk,bhkd->bhqd", attn, v_sel)
        z = z.transpose(1, 2).contiguous().view(b, t, d)
        return self.out(z)


class _EncLayer(nn.Module):
    def __init__(self, d_model, n_heads, sampling, d_ff, dropout=0.1):
        super(_EncLayer, self).__init__()
        self.attn = ProbSparseAttention(d_model, n_heads, sampling)
        self.norm1 = nn.LayerNorm(d_model)
        self.ff = nn.Sequential(nn.Linear(d_model, d_ff), nn.ReLU(),
                                nn.Linear(d_ff, d_model))
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = self.norm1(x + self.dropout(self.attn(x)))
        x = self.norm2(x + self.dropout(self.ff(x)))
        return x


class Informer(nn.Module):
    def __init__(self, d_in=None, d_model=128, n_heads=8, n_layers=4,
                 sampling=0.7, d_out=64):
        super(Informer, self).__init__()
        cfg = C.BASELINES["informer"]
        self.d_in = d_in if d_in is not None else len(C.DYNAMIC_FEATURES)
        self.d_model = d_model
        self.sampling = sampling if sampling is not None else \
            cfg["prob_sparse_sampling"]
        n_layers = n_layers if n_layers is not None else cfg["n_encoder_layers"]

        self.embed = nn.Linear(self.d_in, d_model)
        self.layers = nn.ModuleList([_EncLayer(d_model, n_heads, self.sampling,
                                               d_model * 2)
                                     for _ in range(n_layers)])
        self.head = nn.Linear(d_model, 1)

    def forward(self, x, static, adj_geo):
        # x: (B, T, N, C) -> per-node independent time series
        b, t, n, c = x.size()
        x = x.permute(0, 2, 1, 3).reshape(b * n, t, c)
        z = self.embed(x)
        for layer in self.layers:
            z = layer(z)
        z = z.mean(dim=1)                                 # (B*N, d)
        return self.head(z).view(b, n)
