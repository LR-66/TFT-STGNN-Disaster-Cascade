# -*- coding: utf-8 -*-
"""
DCRNN baseline (Section 3.2.1).

Paper configuration: diffusion stride 2, GRU hidden dimension 64, 2 graph
convolutional layers. Implements diffusion convolution (forward / backward
random-walk matrices raised to the power of the diffusion stride) combined
with a GRU recurrent cell.
"""
from __future__ import division

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import config as C


class DiffusionConv(nn.Module):
    """K-step diffusion convolution with directed forward/backward walks."""

    def __init__(self, d_in, d_out, stride=2):
        super(DiffusionConv, self).__init__()
        self.stride = stride
        self.lin = nn.Linear(d_in * (2 * stride + 1), d_out)

    @staticmethod
    def _transition(a):
        """Row-normalized random-walk transition matrices."""
        a = a + torch.eye(a.size(0), device=a.device)
        out = a / (a.sum(dim=1, keepdim=True) + 1e-6)
        return out, out.t()

    def forward(self, x, a):
        # x: (B, N, d_in); a: (N, N)
        b, n, d = x.size()
        af, ab = self._transition(a)
        supports = [x]
        xf, xb = x, x
        for _ in range(self.stride):
            xf = torch.einsum("ij,bjd->bid", af, xf)
            xb = torch.einsum("ij,bjd->bid", ab, xb)
            supports.append(xf)
            supports.append(xb)
        z = torch.cat(supports, dim=-1)                   # (B, N, d*(2K+1))
        return self.lin(z)


class DCRNN(nn.Module):
    def __init__(self, d_in=None, gru_hidden=64, stride=2, n_layers=2,
                 d_out=64):
        super(DCRNN, self).__init__()
        cfg = C.BASELINES["dcrnn"]
        self.d_in = d_in if d_in is not None else len(C.DYNAMIC_FEATURES)
        self.gru_hidden = gru_hidden if gru_hidden is not None else \
            cfg["gru_hidden"]
        self.stride = stride if stride is not None else cfg["diffusion_stride"]
        self.n_layers = n_layers if n_layers is not None else \
            cfg["graph_conv_layers"]

        self.in_conv = DiffusionConv(self.d_in, gru_hidden, self.stride)
        self.grus = nn.ModuleList(
            [nn.GRUCell(gru_hidden, gru_hidden) for _ in range(self.n_layers)])
        self.head = nn.Linear(gru_hidden, 1)

    def forward(self, x, static, adj_geo):
        # x: (B, T, N, C)
        b, t, n, c = x.size()
        h = [torch.zeros(b, n, self.gru_hidden, device=x.device)
             for _ in range(self.n_layers)]
        for tt in range(t):
            inp = self.in_conv(x[:, tt], adj_geo)         # (B, N, h)
            for l in range(self.n_layers):
                h[l] = self.grus[l](inp.view(b * n, self.gru_hidden),
                                    h[l].view(b * n, self.gru_hidden))
                h[l] = h[l].view(b, n, self.gru_hidden)
                inp = h[l]
        return self.head(h[-1]).squeeze(-1)               # (B, N)
