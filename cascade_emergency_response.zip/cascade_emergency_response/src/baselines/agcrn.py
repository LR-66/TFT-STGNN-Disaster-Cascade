# -*- coding: utf-8 -*-
"""
AGCRN baseline (Section 3.2.1).

Paper configuration: node embedding dimension 32, 2 GRU units, hidden state
dimension 64. Node-adaptive parameters generate the graph adjacency from node
embeddings; a two-layer GRU processes the time series with adaptive input
projections (compact variant of the paper's configuration).
"""
from __future__ import division

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import config as C


class AGCRN(nn.Module):
    def __init__(self, n_nodes, d_in=None, node_emb_dim=32, hidden_size=64,
                 gru_units=2, d_out=64):
        super(AGCRN, self).__init__()
        cfg = C.BASELINES["agcrn"]
        self.d_in = d_in if d_in is not None else len(C.DYNAMIC_FEATURES)
        self.node_emb_dim = node_emb_dim if node_emb_dim is not None else \
            cfg["node_emb_dim"]
        self.hidden_size = hidden_size if hidden_size is not None else \
            cfg["hidden_size"]
        self.gru_units = gru_units if gru_units is not None else cfg["gru_units"]

        # node adaptive parameters: embeddings -> per-node graph
        self.emb = nn.Parameter(torch.empty(n_nodes, self.node_emb_dim))
        nn.init.xavier_uniform_(self.emb)
        self.emb_a = nn.Parameter(torch.empty(n_nodes, self.node_emb_dim))
        nn.init.xavier_uniform_(self.emb_a)

        self.in_proj = nn.Linear(self.d_in, self.hidden_size)
        self.grus = nn.ModuleList(
            [nn.GRUCell(self.hidden_size, self.hidden_size)
             for _ in range(self.gru_units)])
        self.head = nn.Linear(self.hidden_size, 1)

    def _adj(self, device):
        """Node-adaptive adjacency: softmax(ReLU(E1 @ E2^T))."""
        a = torch.softmax(F.relu(torch.mm(self.emb, self.emb_a.t())), dim=1)
        return a.to(device)

    def forward(self, x, static, adj_geo):
        b, t, n, c = x.size()
        a = self._adj(x.device)
        h = [torch.zeros(b, n, self.hidden_size, device=x.device)
             for _ in range(self.gru_units)]
        for tt in range(t):
            inp = F.relu(self.in_proj(x[:, tt]))
            # graph mixing before each GRU step (node-adaptive adjacency)
            inp = torch.einsum("ij,bjd->bid", a, inp)
            for l in range(self.gru_units):
                h[l] = self.grus[l](inp.reshape(b * n, self.hidden_size),
                                    h[l].reshape(b * n, self.hidden_size))
                h[l] = h[l].reshape(b, n, self.hidden_size)
                inp = h[l]
        return self.head(h[-1]).squeeze(-1)                # (B, N)
