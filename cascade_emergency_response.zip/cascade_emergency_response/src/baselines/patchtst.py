# -*- coding: utf-8 -*-
"""
PatchTST baseline (Section 3.2.1).

Paper configuration: patch length 24, channel dimension 256, attention heads 8.
Inputs are patched along the time axis and processed by a shared Transformer
encoder per region / channel; the output is pooled to a per-node point
forecast. The d_model is set to 64 to keep CPU memory reasonable — it is
marked as a compact variant in the README.
"""
from __future__ import division

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import config as C


class PatchTST(nn.Module):
    def __init__(self, d_in=None, patch_len=24, d_model=64, n_heads=8,
                 n_layers=3, d_out=64):
        super(PatchTST, self).__init__()
        cfg = C.BASELINES["patchtst"]
        self.d_in = d_in if d_in is not None else len(C.DYNAMIC_FEATURES)
        self.patch_len = patch_len if patch_len is not None else cfg["patch_len"]
        self.d_model = d_model if d_model is not None else cfg["d_model"]
        self.n_heads = n_heads if n_heads is not None else cfg["n_heads"]

        self.patch_emb = nn.Linear(self.patch_len, self.d_model)
        enc_layer = nn.TransformerEncoderLayer(d_model=self.d_model,
                                               nhead=self.n_heads,
                                               dim_feedforward=d_model * 2,
                                               batch_first=True)
        self.encoder = nn.TransformerEncoder(enc_layer, num_layers=n_layers)
        self.head = nn.Linear(self.d_model * self.d_in, 1)

    def forward(self, x, static, adj_geo):
        # x: (B, T, N, C)
        b, t, n, c = x.size()
        x = x.permute(0, 2, 3, 1)                       # (B, N, C, T)
        # pad to a multiple of patch_len then slice into patches
        pad = (self.patch_len - t % self.patch_len) % self.patch_len
        if pad > 0:
            x = F.pad(x, (0, pad))
        tp = x.size(-1)
        n_patch = tp // self.patch_len
        x = x.view(b, n, c, n_patch, self.patch_len)    # (B,N,C,P,plen)
        x = self.patch_emb(x)                           # (B,N,C,P,d)
        x = x.reshape(b * n * c, n_patch, self.d_model)
        x = self.encoder(x)                             # (B*N*C, P, d)
        x = x.mean(dim=1)                               # (B*N*C, d)
        x = x.view(b, n, self.d_model * c)
        return self.head(x).squeeze(-1)                 # (B, N)
