# -*- coding: utf-8 -*-
"""
Graph WaveNet baseline (Section 3.2.1).

Paper configuration: 8 dilated convolutional layers, adaptive embedding
dimension 16, temporal convolutional kernel width 2. Implements dilated causal
convolutions over time interleaved with graph convolutions on both the
adaptive (learnable embedding) and static adjacency.
"""
from __future__ import division

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import config as C


class _TemporalConv(nn.Module):
    """Dilated causal convolution on the time axis (kernel width 2)."""

    def __init__(self, d, kernel=2, dilation=1):
        super(_TemporalConv, self).__init__()
        self.pad = (kernel - 1) * dilation
        self.conv = nn.Conv2d(d, d, (1, kernel), dilation=(1, dilation))

    def forward(self, x):
        # x: (B, d, N, T)
        x = F.pad(x, (self.pad, 0))
        return self.conv(x)


class GraphWaveNet(nn.Module):
    def __init__(self, n_nodes, d_in=None, n_layers=8, emb_dim=16,
                 kernel=2, d_model=32, d_out=64):
        super(GraphWaveNet, self).__init__()
        cfg = C.BASELINES["graphwavenet"]
        self.d_in = d_in if d_in is not None else len(C.DYNAMIC_FEATURES)
        self.n_layers = n_layers if n_layers is not None else \
            cfg["dilated_layers"]
        self.emb_dim = emb_dim if emb_dim is not None else cfg["adaptive_emb_dim"]
        self.kernel = kernel if kernel is not None else cfg["kernel_width"]
        self.d_model = d_model

        self.e1 = nn.Parameter(torch.empty(n_nodes, emb_dim))
        self.e2 = nn.Parameter(torch.empty(n_nodes, emb_dim))
        nn.init.xavier_uniform_(self.e1)
        nn.init.xavier_uniform_(self.e2)

        self.embed = nn.Conv2d(self.d_in, d_model, 1)
        self.tconvs = nn.ModuleList()
        self.sconvs = nn.ModuleList()
        for i in range(self.n_layers):
            dilation = 2 ** (i % 4)
            self.tconvs.append(_TemporalConv(d_model, self.kernel, dilation))
            self.sconvs.append(nn.Conv2d(d_model, d_model, 1))
        self.head = nn.Linear(d_model, 1)

    def forward(self, x, static, adj_geo):
        # x: (B, T, N, C) -> (B, C, N, T)
        b, t, n, c = x.size()
        x = x.permute(0, 3, 2, 1)
        z = self.embed(x)

        # adaptive adjacency (row-normalised)
        a_adapt = torch.softmax(F.relu(torch.mm(self.e1, self.e2.t())),
                                dim=1)
        a_static = adj_geo / (adj_geo.sum(dim=1, keepdim=True) + 1e-6)
        a = 0.5 * a_static + 0.5 * a_adapt

        for i in range(self.n_layers):
            zt = self.tconvs[i](z)
            zg = torch.einsum("ij,bdjt->bdit", a, zt)   # spatial mixing
            z = F.relu(self.sconvs[i](zg) + z)            # residual

        out = z.mean(dim=-1)                               # (B, d, N)
        return self.head(out.transpose(1, 2)).squeeze(-1)  # (B, N)
