# -*- coding: utf-8 -*-
"""
Multi-agent cascade propagation environment (Section 3.1).

Implements the paper's simulation rules exactly:

  * Disaster triggering uses a **Poisson process** for initialization, with
    initial nodes preferentially selected from high-frequency disaster areas
    (EM-DAT / NOAA style regional weights).
  * A cascading propagation event only occurs when region A experiences a
    disaster with intensity exceeding the **local 80th-percentile threshold**
    at time t, and region B experiences a secondary disaster **6 to 72 hours**
    later, with the two regions physically connected on the geographic or
    infrastructure network.
  * Propagation delay is **inversely proportional** to the primary-disaster
    intensity (stronger primary events cascade faster).
  * The target variable — the **Regional Integrated Risk Intensity Index
    (RIRI)** — is the weighted composite of Eq. (12):

        RIRI = w_h * Hazard + w_i * Infrastructure + w_p * Population
        with (w_h, w_i, w_p) = (0.5, 0.3, 0.2)

    * Hazard:        normalized river stage above the warning level
                     (hydrological early-warning practice);
    * Infrastructure: fraction of disrupted infrastructure assets, derived
                     from the inundation extent overlaying the OSM-style
                     infrastructure layer (capacity / redundancy aware);
    * Population:    fraction of the regional population in inundated zones,
                     based on WorldPop-style population density.
"""
from __future__ import division

import numpy as np

from config import config as C
from src.simulation import hydrology as H


class CascadeEnvironment(object):
    """Simulates multi-source covariates, cascade events and the RIRI target."""

    def __init__(self, static, graph, rng, sim_cfg=None):
        self.static = static
        self.graph = graph
        self.rng = rng
        self.cfg = sim_cfg or C.SIM
        self.n = len(static["elevation_m"])
        self.down = graph["adj_geo"]                 # (N, N) flow direction
        self.warning = 2.0
        self.levee = 8.0

    # ------------------------------------------------------------------ #
    # Covariate generation (Table 1 of the paper)
    # ------------------------------------------------------------------ #
    def _wind_and_temp(self, T):
        """wind speed [0,30] m/s gamma-skewed; air temperature [0,40] seasonal."""
        t = np.arange(T)
        season = 0.5 + 0.5 * np.sin(2 * np.pi * t / (24.0 * 365.0) - np.pi / 2)
        wind = self.rng.gamma(2.0, 2.0, size=(T, self.n)) * 2.5
        wind = np.clip(wind, 0.0, 30.0)
        temp = (8.0 + 24.0 * season[:, None] +
                self.rng.normal(0, 1.5, size=(T, self.n)))
        temp = np.clip(temp, 0.0, 40.0)
        return wind, temp

    def _public_opinion(self, T, disaster_series):
        """
        Discrete public-opinion indicators coupled with the disaster process:
        keyword frequency, help requests and traffic incident reports surge in
        a 24h window after each cascade event.
        """
        base_kw = self.rng.lognormal(3.0, 0.9, size=(T, self.n)) * 3.0
        base_help = self.rng.lognormal(2.0, 0.8, size=(T, self.n)) * 2.0
        base_traffic = self.rng.lognormal(1.0, 0.7, size=(T, self.n)) * 2.0

        kw, hp, tr = base_kw.copy(), base_help.copy(), base_traffic.copy()
        # disaster_series: (T, N) event intensity; add surge within 24h window
        for lag in range(0, 24):
            if lag == 0:
                src = disaster_series
            else:
                src = np.zeros_like(disaster_series)
                src[lag:, :] = disaster_series[: T - lag, :]
            kw += src * (1200.0 / (lag + 4.0))
            hp += src * (500.0 / (lag + 4.0))
            tr += src * (80.0 / (lag + 4.0))

        kw = np.clip(kw, 0, 5000)
        hp = np.clip(hp, 0, 2000)
        tr = np.clip(tr, 0, 300)
        return dict(disaster_keyword_freq=kw, help_requests=hp,
                    traffic_incidents=tr)

    # ------------------------------------------------------------------ #
    # Cascade event simulation (Section 3.1 rules)
    # ------------------------------------------------------------------ #
    def _simulate_cascade(self, T, stage):
        """
        Discrete-event cascade simulation.

        Simulation rules (Section 3.1):
          * initial events follow a per-node Poisson process, with nodes
            drawn from EM-DAT style hotspot weights;
          * a region A triggers cascading propagation only if its event
            intensity exceeds the local 80th-percentile threshold;
          * the secondary event in a connected region B arrives 6-72 h later,
            the delay being inversely proportional to the primary intensity;
          * a 72 h recovery constraint prevents infinite cascade loops
            (a region cannot be re-triggered while still recovering).

        Returns
        -------
        event_series : (T, N) float event intensity (0 = no event)
        delays       : list of realized propagation delays (hours) for the
                       statistical validation of the paper (mean ~16.8 h)
        """
        n = self.n
        cfg = self.cfg
        ev = np.zeros((T, n))

        # local 80th-percentile threshold from the physically derived stage
        thr = np.percentile(stage, cfg["trigger_percentile"] * 100.0,
                            axis=0)
        # cascading only propagates from events well above the local level
        trigger_level = 1.8 * thr

        # EM-DAT style regional weights: downstream & dense nodes are hotspots
        hotspot = (self.static["population_density"] /
                   self.static["population_density"].max())
        hotspot = 0.3 + 0.7 * hotspot
        hotspot = hotspot / hotspot.sum()

        # per-node Poisson initialisation (rare, disaster-like)
        lam_node = 0.0012
        initial = self.rng.poisson(lam_node, size=(T, n))

        delays = []
        attenuation = 0.70
        recovery_h = 72.0
        last_hit = np.full(n, -1e9)

        # pending secondary events: list of (time, node, intensity)
        pending = []

        for t in range(T):
            # fire pending cascade events at time t
            keep = []
            for (tt, node, intens) in pending:
                if tt <= t:
                    if t - last_hit[node] >= recovery_h or ev[t, node] == 0:
                        ev[t, node] = max(ev[t, node], intens)
                        last_hit[node] = t
                else:
                    keep.append((tt, node, intens))
            pending = keep

            # initial Poisson triggers (hotspot weighted)
            n_init = int(initial[t].sum())
            if n_init > 0:
                nodes = self.rng.choice(n, size=n_init, p=hotspot)
                for node in nodes:
                    node = int(node)
                    if t - last_hit[node] < recovery_h:
                        continue
                    x = self.rng.gamma(2.0, 1.0)
                    intens = thr[node] * (1.0 + x)
                    ev[t, node] = max(ev[t, node], intens)
                    last_hit[node] = t

            # cascade: only events well above the local threshold propagate
            for node in range(n):
                e = ev[t, node]
                if e <= trigger_level[node]:
                    continue
                # relative excess intensity X (Eq. 3.1 cascade rule)
                x = max((e - thr[node]) / (thr[node] + 1e-6), 0.0)
                # delay in [6, 72] h, inversely proportional to intensity
                delay = cfg["delay_max_h"] * np.exp(-1.3 * x)
                delay = float(np.clip(delay, cfg["delay_min_h"],
                                      cfg["delay_max_h"]))
                t_arrive = t + int(round(delay))
                if t_arrive >= T:
                    continue
                # downstream / connected neighbours
                for j in np.where(self.down[node] > 0)[0]:
                    if t_arrive - last_hit[j] < recovery_h:
                        continue
                    child_intensity = e * attenuation * (0.8 +
                                                         0.4 * self.rng.random())
                    pending.append((t_arrive, j, float(child_intensity)))
                    delays.append(delay)

        return ev, np.asarray(delays)

    # ------------------------------------------------------------------ #
    # RIRI target (Eq. 12)
    # ------------------------------------------------------------------ #
    def _rir_index(self, stage, inundation, event_series):
        """Compute the Regional Integrated Risk Intensity Index."""
        st = self.static
        hazard = np.clip((stage - self.warning) / (self.levee - self.warning),
                         0.0, 1.0)
        # event boost: cascade events push stage above the levee locally
        boost = np.clip(event_series / (self.levee * 1.5), 0.0, 1.0)
        hazard = np.clip(hazard + 0.35 * boost, 0.0, 1.0)

        # infrastructure disruption: inundation x (1 - redundancy) weighted
        redundancy = st["road_redundancy"]
        capacity_norm = np.clip(st["infrastructure_capacity"] / 5.0, 0.2, 1.2)
        infra = inundation * (1.25 - 0.5 * redundancy) / capacity_norm
        infra = np.clip(infra, 0.0, 1.0)

        # population exposure: inundation x normalized density
        pop_norm = np.clip(st["population_density"] / 3000.0, 0.0, 1.0)
        pop = inundation * (0.4 + 0.6 * pop_norm)
        pop = np.clip(pop, 0.0, 1.0)

        w = C.RIRI_WEIGHTS
        riri = (w["hazard"] * hazard + w["infrastructure"] * infra +
                w["population"] * pop)
        return np.clip(riri, 0.0, 1.0).astype(np.float32)

    # ------------------------------------------------------------------ #
    # Full simulation
    # ------------------------------------------------------------------ #
    def simulate(self, T):
        """
        Run the whole multi-agent simulation for T hours.

        Returns
        -------
        dict with keys:
            covariates : {name: (T, N) array} for every DYNAMIC_FEATURE
            stage      : (T, N) river stage
            riri       : (T, N) target index
            delays     : (K,) realized cascade delays (h)
            event_series: (T, N) cascade event intensity
        """
        rng = self.rng
        hydro = H.simulate_hydrology(self.static, self.down,
                                     self.graph["dist_km"], T, rng)
        stage = hydro["stage"]
        inundation = hydro["inundation"]

        event_series, delays = self._simulate_cascade(T, stage)

        wind, temp = self._wind_and_temp(T)
        opinion = self._public_opinion(T, event_series)

        covariates = {
            "rainfall": hydro["rainfall"],
            "river_level": stage,
            "wind_speed": wind,
            "air_temp": temp,
            "disaster_keyword_freq": opinion["disaster_keyword_freq"],
            "help_requests": opinion["help_requests"],
            "traffic_incidents": opinion["traffic_incidents"],
        }
        riri = self._rir_index(stage, inundation, event_series)
        return dict(covariates=covariates, stage=stage, riri=riri,
                    delays=delays, event_series=event_series)
