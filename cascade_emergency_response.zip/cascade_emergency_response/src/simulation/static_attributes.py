# -*- coding: utf-8 -*-
"""
Static regional attributes (Section 3.1).

Each node is a hydro-meteorologically coherent unit (synthetic sub-basin /
catchment). Its static attributes are sampled from distributions calibrated
with the public data sources named in the paper:

  * elevation          -> SRTM 30m DEM (gamma-shaped, clipped to [0, 3000] m)
  * population density -> WorldPop 1km rasters (log-normal)
  * road redundancy    -> OpenStreetMap road network redundancy (beta-like)
  * infrastructure cap -> log-normal (Table 1)

Spatial locations are laid out on a planar domain that mimics a drainage
network; the y-coordinate acts as the "upstream-to-downstream" direction so
that hydrological routing (see hydrology.py) is physically meaningful.
"""
from __future__ import division

import numpy as np

from config import config as C

_CFG = C.STATIC_FEATURES
_DOMAIN_KM = 600.0          # planar domain side length (km)


def _log_normal(rng, mu, sigma, clip, size):
    """Draw from a log-normal distribution with parameters (mu, sigma)."""
    vals = np.exp(rng.normal(mu, sigma, size=size))
    return np.clip(vals, clip[0], clip[1])


def generate_static_attributes(num_nodes, rng):
    """
    Return a dict of static attributes of shape (num_nodes,) each:

        lat, lon                  : planar coordinates (km)
        elevation_m               : SRTM-style elevation
        population_density        : WorldPop-style density (persons / km^2)
        road_redundancy           : OSM-style road redundancy in [0.05, 1]
        infrastructure_capacity   : log-normal capacity index
        region_type               : 0 = upstream, 1 = midstream, 2 = downstream

    The region type is derived from elevation quantiles: low-lying nodes are
    downstream (and therefore more exposed to cascade propagation).
    """
    n = num_nodes
    lon = rng.uniform(0.0, _DOMAIN_KM, size=n)
    lat = rng.uniform(0.0, _DOMAIN_KM, size=n)

    elev_cfg = _CFG["elevation_m"]
    elevation_m = np.clip(rng.gamma(2.0, elev_cfg["mean"] / 2.0, size=n),
                          elev_cfg["clip"][0], elev_cfg["clip"][1])

    pop_cfg = _CFG["population_density"]
    population_density = _log_normal(rng, pop_cfg["mu"], pop_cfg["sigma"],
                                     pop_cfg["clip"], n)

    road_cfg = _CFG["road_redundancy"]
    road_redundancy = np.clip(
        rng.beta(2.5, 2.0, size=n) * road_cfg["mean"] * 2.0,
        road_cfg["clip"][0], road_cfg["clip"][1])

    cap_cfg = _CFG["infrastructure_capacity"]
    infrastructure_capacity = _log_normal(rng, cap_cfg["mu"], cap_cfg["sigma"],
                                          cap_cfg["clip"], n)

    # region type: 1/3 lowest elevation -> upstream(0), middle -> midstream(1),
    # 1/3 highest elevation -> ... actually lowest lying -> downstream(2).
    elev_q = np.argsort(np.argsort(elevation_m)) / float(n)   # rank in [0,1)
    region_type = np.where(elev_q < 1.0 / 3.0, 0,
                           np.where(elev_q < 2.0 / 3.0, 1, 2)).astype(int)

    return dict(
        lat=lat, lon=lon,
        elevation_m=elevation_m,
        population_density=population_density,
        road_redundancy=road_redundancy,
        infrastructure_capacity=infrastructure_capacity,
        region_type=region_type,
    )


def static_matrix(static):
    """
    Stack static attributes into an (N, D_s) numeric matrix used by models.
    Region type is one-hot encoded; all channels are standardized.
    """
    n = len(static["elevation_m"])
    rt = static["region_type"]
    one_hot = np.zeros((n, 3), dtype=np.float32)
    one_hot[np.arange(n), rt] = 1.0
    cols = [
        static["elevation_m"] / 1000.0,                 # scale to km-unit
        np.log1p(static["population_density"]),
        static["road_redundancy"],
        np.log1p(static["infrastructure_capacity"]),
    ]
    X = np.stack(cols, axis=1).astype(np.float32)
    X = np.concatenate([X, one_hot], axis=1)
    # standardize per column
    mu = X.mean(axis=0, keepdims=True)
    sd = X.std(axis=0, keepdims=True) + 1e-6
    return (X - mu) / sd
