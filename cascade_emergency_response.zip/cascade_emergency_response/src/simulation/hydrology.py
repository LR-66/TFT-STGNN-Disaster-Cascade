# -*- coding: utf-8 -*-
"""
LISFLOOD-style hydrological simulation (Section 3.1).

A lightweight but physically consistent linear-reservoir rainfall-runoff model:

    1. Rainfall: seasonal cycle + right-skewed (gamma) stochastic storm bursts.
    2. Runoff:   linear reservoir S[t] = (1 - k) * S[t-1] + rain * c,
                 discharge flow[t] = k * S[t].
    3. Routing:  every downstream node receives the discharge of its upstream
                 neighbours delayed by (distance / wave speed) hours,
                 mimicking flood-wave travel along the drainage network.
    4. Stage:    river stage wl[t] = wl0 + (flow / ref) ** 0.7, clipped to the
                 [0, 10] m range of Table 1.
    5. Inundation fraction: fraction of the node that is flooded when the stage
                 exceeds the bankfull level (used for RIRI, Eq. 12).

The routing direction is strictly upstream -> downstream (respecting the DEM
flow direction), which is the physical basis of the directed graph edges used
by the ST-GNN module.
"""
from __future__ import division

import numpy as np


def _seasonal_factor(t, phase=0.0):
    """Annual sinusoidal seasonality (peak in summer for the study area)."""
    return 0.5 + 0.5 * np.sin(2.0 * np.pi * t / (24.0 * 365.0) + phase)


def _rainfall(rng, static, T):
    """
    Hourly rainfall [mm/h] per node with seasonality + gamma storm bursts.
    Returns array of shape (T, N).
    """
    n = len(static["elevation_m"])
    # base seasonal intensity; mountainous (upstream) nodes are wetter
    base = 1.0 + 1.5 * (static["elevation_m"] / 1000.0).clip(0, 1)
    t = np.arange(T)
    season = _seasonal_factor(t)[:, None]          # (T, 1)
    # occasional storm bursts: poisson events with gamma magnitudes
    burst = np.zeros((T, n), dtype=np.float64)
    n_events = rng.poisson(0.02, size=T)           # ~ every 2 days somewhere
    for t_i in np.where(n_events > 0)[0]:
        n_e = n_events[t_i]
        nodes = rng.randint(0, n, size=n_e)
        mag = rng.gamma(shape=4.0, scale=6.0, size=n_e)   # mm/h, right-skewed
        burst[t_i, nodes] += mag
    intensity = (base[None, :] * (season * 3.0 + 0.4) + burst)
    return np.clip(intensity, 0.0, 100.0)


def simulate_hydrology(static, adj_down, dist_km, T, rng,
                       reservoir_k=0.15, wave_speed_kmh=8.0,
                       ref_discharge=6.0, wl0=1.2, bankfull=2.2, levee=8.0):
    """
    Run the linear-reservoir model for T hours.

    Parameters
    ----------
    static   : dict from static_attributes.generate_static_attributes
    adj_down : (N, N) directed downstream-adjacency: adj_down[j, i] = 1 if i is
               a direct upstream neighbour of j (flow travels i -> j)
    dist_km  : (N, N) pairwise distances (km)
    T        : number of hours
    rng      : numpy RandomState

    Returns
    -------
    dict with keys:
        rainfall   (T, N) mm/h
        flow       (T, N) m^3/s
        stage      (T, N) m          (river water level)
        inundation (T, N) in [0, 1]  flooded fraction of the node
    """
    n = len(static["elevation_m"])
    rainfall = _rainfall(rng, static, T)

    # linear reservoir per node (local generation)
    storage = np.zeros(n)
    local = np.zeros((T, n))
    k = reservoir_k
    c = 1.2
    for t in range(T):
        storage = (1.0 - k) * storage + c * rainfall[t]
        local[t] = k * storage

    # upstream -> downstream routing with travel delay
    routed = np.zeros((T, n))
    delay_h = np.full((n, n), 1.0)
    for j in range(n):
        for i in range(n):
            if adj_down[j, i] > 0:
                delay_h[j, i] = max(1.0, dist_km[j, i] / wave_speed_kmh)
    for j in range(n):
        routed[:, j] = local[:, j].copy()
        for i in range(n):
            if adj_down[j, i] > 0:
                d = int(round(delay_h[j, i]))
                up_series = np.zeros(T)
                up_series[: T - d] = local[: T - d, i]
                routed[:, j] += 0.6 * up_series

    flow = np.maximum(routed, 0.0)
    # stage from discharge: nonlinear rating curve
    stage = wl0 + (flow / ref_discharge) ** 0.7
    stage = np.clip(stage, 0.0, 10.0)

    # inundated fraction once stage exceeds bankfull
    inundation = np.clip((stage - bankfull) / (levee - bankfull), 0.0, 1.0)

    return dict(rainfall=rainfall, flow=flow, stage=stage, inundation=inundation)
