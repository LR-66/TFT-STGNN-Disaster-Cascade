# -*- coding: utf-8 -*-
"""
Graph construction (Section 2.3 / 3.1).

Edges exist between two regions if:
  * geographic distance <= 50 km, or
  * a direct road link exists in the OSM-style road network,
  * AND hydrological connectivity (flow direction) permits it.

Edge weights are initialised as inverse distance (paper: "adaptive edge
weights initialized as inverse distance and updated during training").

The adjacency is kept **asymmetric** to preserve the directional nature of
flood propagation (upstream -> downstream) and infrastructure dependency
paths, exactly as required by Eq. (9) of the paper.
"""
from __future__ import division

import numpy as np

from config import config as C


def _pairwise_dist(lat, lon):
    """Euclidean distances (km) on the planar simulation domain."""
    d = np.sqrt((lat[:, None] - lat[None, :]) ** 2 +
                (lon[:, None] - lon[None, :]) ** 2)
    np.fill_diagonal(d, np.inf)
    return d


def build_geographic_adjacency(static, rng, distance_threshold_km=None,
                               road_link_prob=None):
    """
    Build the initial hybrid geographic graph.

    Returns
    -------
    dict with keys:
        dist_km  : (N, N) pairwise distances
        adj_geo  : (N, N) asymmetric boolean adjacency (flow direction)
        w_geo    : (N, N) float weights (inverse distance)
        edge_list: list of (i, j, w) edges for CSV export
    """
    if distance_threshold_km is None:
        distance_threshold_km = C.SIM["distance_threshold_km"]
    if road_link_prob is None:
        road_link_prob = C.SIM["road_link_prob"]

    n = len(static["elevation_m"])
    lat, lon = static["lat"], static["lon"]
    dist_km = _pairwise_dist(lat, lon)

    # road connectivity: independent per pair, OSM-style
    road = rng.uniform(size=(n, n)) < road_link_prob
    road = road | road.T
    np.fill_diagonal(road, False)

    geo = dist_km <= distance_threshold_km

    # upstream index (lower elevation => upstream; flow travels up -> down)
    upstream_of = static["elevation_m"][None, :] > static["elevation_m"][:, None]
    # a directed edge exists i -> j if i is upstream of j (or equal elevation)
    # and the pair is connected geographically or by road
    base = (geo | road) & ~np.eye(n, dtype=bool)
    # flow direction: prefer upstream -> downstream
    adj = base & (upstream_of | (static["elevation_m"][:, None] ==
                                 static["elevation_m"][None, :]))

    # keep at least a small undirected component so graphs stay connected
    deg = adj.sum(axis=1)
    if (deg == 0).any():
        for i in np.where(deg == 0)[0]:
            j = int(np.argmin(dist_km[i]))
            adj[i, j] = True
            adj[j, i] = True

    # weights: inverse distance (small eps to avoid division by zero)
    eps = 1e-3
    w_geo = np.where(adj, 1.0 / (dist_km + eps), 0.0)
    # normalize rows to keep spectral radius under control (Eq. 9 normalization)
    row_sum = w_geo.sum(axis=1, keepdims=True)
    w_geo = np.where(row_sum > 0, w_geo / (row_sum + eps), 0.0)

    edge_list = []
    rows, cols = np.where(adj)
    for i, j in zip(rows.tolist(), cols.tolist()):
        edge_list.append((i, j, float(w_geo[i, j])))

    return dict(dist_km=dist_km, adj_geo=adj.astype(np.float32),
                w_geo=w_geo.astype(np.float32), edge_list=edge_list)
