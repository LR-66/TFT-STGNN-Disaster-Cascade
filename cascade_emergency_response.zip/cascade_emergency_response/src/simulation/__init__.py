# -*- coding: utf-8 -*-
"""Simulation package: multi-agent cascade generation (data-availability item 1)."""
