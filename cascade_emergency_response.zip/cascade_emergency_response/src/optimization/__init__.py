# -*- coding: utf-8 -*-
"""Optimization package (data-availability item 6)."""
