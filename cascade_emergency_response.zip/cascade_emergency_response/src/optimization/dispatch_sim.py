# -*- coding: utf-8 -*-
"""
Dispatch execution simulation (Section 3.2.2 / 4.5).

Evaluates the scheduling plans with the paper's robustness indicators:

  * Order fulfillment rate  : fraction of the (chance-constrained) demand that
                              is covered by the plan;
  * On-time delivery rate   : fraction of delivered units arriving within the
                              allowed arrival time window;
  * Response time           : time from disaster trigger to the arrival of the
                              first wave of rescue resources (aligned with the
                              simulation timestamp, Section 3.2.2).

Also supports the data-missing scenarios (5 % - 40 %) used by Section 4.5:
the demand used by the optimizer is derived from predictions degraded by the
missing-data fraction, and the resulting plan is scored against the full
(true) demand.
"""
from __future__ import division

import numpy as np

from config import config as C


def simulate_dispatch(plan, demand_true, dist_km, travel_speed_kmh=None,
                      window_h=None):
    """
    Compute fulfillment / on-time / response metrics for a schedule.

    plan          : {(i, r): amount} allocation
    demand_true   : (N,) true demand per region (supplies)
    dist_km       : (N,) distance from depot to region i
    travel_speed_kmh : convoy speed (default from config)
    window_h      : maximum acceptable delivery delay in hours
    """
    cfg = C.OPT
    speed = travel_speed_kmh if travel_speed_kmh is not None else \
        cfg["travel_time_km_h"]
    window_h = window_h if window_h is not None else 24.0

    n = len(demand_true)
    delivered = np.zeros(n)
    arrival_times = np.full(n, np.inf)
    for (i, r), amt in plan.items():
        if r != 0:                       # supplies resource type
            continue
        delivered[i] += amt

    total_demand = max(demand_true.sum(), 1e-6)
    fulfillment = min(1.0, delivered.sum() / total_demand)

    # on-time: travel time <= window
    travel = np.where(dist_km > 0, dist_km / speed, 0.0)
    on_time = (travel <= window_h)
    # on-time delivery rate weighted by delivered quantity
    delivered_supplies = np.minimum(delivered, demand_true)
    on_time_rate = (delivered_supplies[on_time].sum() /
                    (delivered_supplies.sum() + 1e-6))

    # response time: first arrival among dispatched regions with demand
    hit = np.where(delivered_supplies > 0)[0]
    if len(hit) > 0:
        response_h = float(travel[hit].min())
    else:
        response_h = float("inf")

    return dict(fulfillment_rate=float(fulfillment),
                on_time_rate=float(on_time_rate),
                response_time_h=response_h,
                delivered=delivered.tolist())


def robustness_across_missing(risk_true, dist_km, missing_rates=None,
                              make_prediction_fn=None):
    """
    Section 4.5: fulfillment / on-time rates under data-missing scenarios
    (5 % - 40 %). `make_prediction_fn(missing_frac)` should return the
    degraded (p10, p50, p90) predictions used by the optimizer.
    """
    from src.optimization.emergency_optimizer import solve_schedule

    missing_rates = missing_rates if missing_rates is not None else \
        C.METRICS["missing_rates"]
    results = {}
    for frac in missing_rates:
        if make_prediction_fn is not None:
            p10, p50, p90 = make_prediction_fn(frac)
        else:
            p10 = p50 = p90 = risk_true
        res = solve_schedule(p50, p10, p50, p90, dist_km)
        demand_true = np.clip(risk_true, 0.0, 1.0) * C.OPT["demand_base"]
        m = simulate_dispatch(res["plan"], demand_true, dist_km)
        results[frac] = dict(
            fulfillment_rate=m["fulfillment_rate"],
            on_time_rate=m["on_time_rate"],
            solve_time=res["solve_time"], solver=res["solver"])
    return results
