# -*- coding: utf-8 -*-
"""
Emergency resource scheduling optimizer (Section 2.4, Eq. 14 - 15).

Converts the TFT-ST-GNN quantile predictions (P10 / P90) into a chance
constraint via the truncated-normal mapping of the paper:

    mu    = (P10 + P90) / 2
    sigma = (P90 - P10) / (2 * Phi^{-1}(0.90))
    Pr(demand_i <= sum x) >= alpha  <=>  sum x >= mu + z_alpha * sigma

For alpha = 0.95 this reduces to allocating the upper quantile P90
(guaranteeing 95% demand coverage), exactly as derived in the paper.

Solver strategy:
  * Gurobi (gurobipy >= 9.5) when available — with the 60 s time limit of
    the paper;
  * otherwise a deterministic priority-based greedy allocation that respects
    the same objective priorities (weighted delay + fairness), so the
    pipeline runs on any machine. The LP model file is always exported.
"""
from __future__ import division

import os
import time

import numpy as np

from config import config as C
from src.optimization import lp_writer

# standard normal inverse CDF at 0.90 (z_0.9 = 1.2816) and 0.95
Z_90 = 1.2816
Z_95 = 1.6449


def _normal_inv_cdf(p):
    """Acklam's rational approximation of the standard normal quantile."""
    if p <= 0.0:
        return -6.0
    if p >= 1.0:
        return 6.0
    a = [-3.969683028665376e+01, 2.209460984245205e+02,
         -2.759285104469687e+02, 1.383577518672690e+02,
         -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02,
         -1.556989798598866e+02, 6.680131188771972e+01,
         -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01,
         -2.400758277161838e+00, -2.549732539343734e+00,
         4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01,
         2.445134137142996e+00, 3.754408661907416e+00]
    plow = 0.02425
    if p < plow:
        q = np.sqrt(-2.0 * np.log(p))
        return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q +
                c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0)
    if p <= 1.0 - plow:
        q = p - 0.5
        r = q * q
        return (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r +
                a[5]) * q / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r +
                              b[4]) * r + 1.0)
    q = np.sqrt(-2.0 * np.log(1.0 - p))
    return -(((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q +
             c[5]) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1.0)


def quantile_demand(p10, p50, p90, alpha=0.95, base=200.0):
    """
    Chance-constrained demand from the quantile predictions (Eq. 15 mapping).

    Returns the alpha-quantile of the demand distribution per region.
    """
    p10 = np.asarray(p10, dtype=np.float64)
    p50 = np.asarray(p50, dtype=np.float64)
    p90 = np.asarray(p90, dtype=np.float64)
    mu = (p10 + p90) / 2.0
    sigma = (p90 - p10) / (2.0 * Z_90)
    sigma = np.clip(sigma, 1e-4, None)
    z_alpha = _normal_inv_cdf(alpha)
    demand_norm = mu + z_alpha * sigma
    demand = np.clip(demand_norm, 0.0, 1.0) * base
    return demand


def _solve_gurobi(n, r_count, demand, budgets, capacities, weights,
                  time_limit):
    """Gurobi MILP solve (branch and bound), 60 s limit."""
    import gurobipy as gp
    from gurobipy import GRB

    m = gp.Model("emergency_scheduling")
    m.setParam("OutputFlag", 0)
    m.setParam("TimeLimit", time_limit)
    x = m.addVars(n, r_count, vtype=GRB.INTEGER, name="x")
    # objective: weighted allocation (delay proxy = 1 - priority)
    m.setObjective(
        sum(weights[i] * x[i, r] for i in range(n) for r in range(r_count)),
        GRB.MINIMIZE)
    # demand coverage (chance constraint, alpha-quantile)
    for i in range(n):
        for r in range(r_count):
            m.addConstr(x[i, r] >= demand[i, r], "demand_%d_%d" % (i, r))
    # total budget
    for r in range(r_count):
        m.addConstr(sum(x[i, r] for i in range(n)) <= budgets[r],
                    "budget_%d" % r)
    # path capacity
    for i in range(n):
        for r in range(r_count):
            m.addConstr(x[i, r] <= capacities[i, r], "cap_%d_%d" % (i, r))
    m.optimize()
    if m.status == GRB.OPTIMAL or m.status == GRB.SUBOPTIMAL:
        plan = {(i, r): int(round(x[i, r].X)) for i in range(n)
                for r in range(r_count)}
        return plan, m.Runtime
    return None, m.Runtime


def _solve_greedy(n, r_count, demand, budgets, capacities, weights):
    """
    Deterministic priority allocation (fallback when Gurobi is absent).
    Regions are processed by descending priority weight; each region receives
    up to its demand subject to budget and path capacity.
    """
    plan = {}
    budget_left = np.asarray(budgets, dtype=np.float64).copy()
    order = np.argsort(-np.asarray(weights))
    for i in order:
        for r in range(r_count):
            amt = min(demand[i, r], capacities[i, r], budget_left[r])
            plan[(int(i), r)] = int(round(amt))
            budget_left[r] -= amt
    return plan, 0.0


def solve_schedule(risk, p10, p50, p90, dist_km, opt_cfg=None):
    """
    Full scheduling entry point.

    risk   : (N,) predicted median risk (P50), normalized
    p10/p90: (N,) quantile bounds
    dist_km: (N,) distance from the emergency depot to each region (km)

    Returns dict:
        plan       : {(i, r): amount}
        demand     : (N, R) alpha-quantile demands
        budgets    : (R,)
        capacities : (N, R) degraded path capacities
        solve_time : seconds
        solver     : 'gurobi' | 'priority'
        lp_file    : path of the exported LP model
    """
    cfg = opt_cfg or C.OPT
    n = len(risk)
    r_count = 2                       # resource types: supplies, personnel
    budgets = np.array([cfg["total_supplies"], cfg["total_personnel"]],
                       dtype=np.float64)

    demand_alpha = quantile_demand(p10, p50, p90, cfg["alpha"],
                                   cfg["demand_base"])
    demand = np.stack([demand_alpha, demand_alpha * 0.05], axis=1)

    # time-varying path capacity degradation: C = C0 * (1 - s * risk)
    s = cfg["damage_sensitivity"]
    capacity = np.array([[cfg["capacity_supplies"], cfg["capacity_personnel"]]
                         for _ in range(n)], dtype=np.float64)
    capacity *= (1.0 - s * np.clip(np.asarray(risk), 0.0, 1.0))[:, None]

    # priority weight: risk level (higher risk -> smaller delay weight)
    weights = 1.0 - np.clip(np.asarray(risk), 0.0, 1.0)

    # export the LP model always (data-availability item 6)
    lp_file = os.path.join(C.LP_DIR, "scheduling_model.lp")
    lp_writer.write_lp(lp_file, np.asarray(risk), demand, capacity, budgets,
                       weights, time_windows=None, gamma=cfg["gamma"])
    t0 = time.time()
    try:
        import gurobipy  # noqa: F401
        solver = "gurobi"
        plan, gurobi_t = _solve_gurobi(n, r_count, demand, budgets, capacity,
                                       weights, cfg["gurobi_time_limit_s"])
        solve_time = gurobi_t
    except ImportError:
        solver = "priority"
        plan, _ = _solve_greedy(n, r_count, demand, budgets, capacity, weights)
        solve_time = time.time() - t0

    return dict(plan=plan, demand=demand, budgets=budgets,
                capacities=capacity, solve_time=solve_time, solver=solver,
                lp_file=lp_file, weights=weights)
