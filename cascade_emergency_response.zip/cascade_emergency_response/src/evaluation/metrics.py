# -*- coding: utf-8 -*-
"""
Evaluation metrics (Section 3.2.2, Eq. 16 - 19 and Section 4.1).

Implements the paper's full indicator system:

  * Prediction accuracy:
      - RMSE (Eq. 16), MAE (Eq. 17) on the normalized RIRI target;
  * Extreme event capture:
      - recall (Eq. 18), precision, F1 (Eq. 19) — positive samples are
        moments with risk intensity above the historical 90th percentile;
  * Probabilistic calibration (80 % interval, P10-P90):
      - PICP   : prediction interval coverage probability;
      - PINAW  : prediction interval normalized average width;
      - CRPS   : continuous ranked probability score (closed form for the
                 truncated-normal approximation used in Eq. 15);
      - Winkler: combined width / coverage-violation score.

All metrics can be aggregated as mean +/- std over several independent runs.
"""
from __future__ import division

import numpy as np

from config import config as C

_Z90 = 1.2816


def _erf(x):
    """Vectorised erf via Abramowitz & Stegun 7.1.26 (|err| < 1.5e-7).
    numpy < 1.22 does not expose np.erf, so this keeps the package
    dependency-free."""
    x = np.asarray(x, dtype=np.float64)
    p = 0.3275911
    a1, a2, a3, a4, a5 = (0.254829592, -0.284496736, 1.421413741,
                          -1.453152027, 1.061405429)
    sign = np.sign(x)
    ax = np.abs(x)
    t = 1.0 / (1.0 + p * ax)
    y = (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t
    return sign * (1.0 - y * np.exp(-ax * ax))


def _normal_cdf(z):
    """Standard normal CDF via the error function (no scipy needed)."""
    return 0.5 * (1.0 + _erf(z / np.sqrt(2.0)))


def _normal_pdf(z):
    return np.exp(-0.5 * z ** 2) / np.sqrt(2.0 * np.pi)


# ---------------------------------------------------------------------- #
# Point metrics (Eq. 16 - 19)
# ---------------------------------------------------------------------- #
def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2)))


def mae(y_true, y_pred):
    return float(np.mean(np.abs(np.asarray(y_true) - np.asarray(y_pred))))


def extreme_metrics(y_true, y_pred, q=None, threshold=None):
    """
    Recall / precision / F1 for extreme-event identification (Eq. 18-19).
    Positive = risk above the historical 90th percentile by default.
    """
    y_true = np.asarray(y_true).ravel()
    y_pred = np.asarray(y_pred).ravel()
    if threshold is None:
        q = q if q is not None else C.METRICS["extreme_quantile"]
        threshold = float(np.percentile(y_true, q * 100.0))
    pos = y_true > threshold
    pred_pos = y_pred > threshold
    tp = float((pos & pred_pos).sum())
    fn = float((pos & ~pred_pos).sum())
    fp = float((~pos & pred_pos).sum())
    recall = tp / (tp + fn + 1e-12)
    precision = tp / (tp + fp + 1e-12)
    f1 = 2 * precision * recall / (precision + recall + 1e-12)
    return dict(recall=recall, precision=precision, f1=f1, tp=tp, fp=fp, fn=fn)


# ---------------------------------------------------------------------- #
# Probabilistic metrics (Section 4.1)
# ---------------------------------------------------------------------- #
def picp(y_true, lo, hi):
    """Prediction interval coverage probability (nominal 0.80)."""
    y = np.asarray(y_true).ravel()
    lo = np.asarray(lo).ravel()
    hi = np.asarray(hi).ravel()
    return float(np.mean((y >= lo) & (y <= hi)))


def pinaw(y_true, lo, hi):
    """Prediction interval normalized average width (normalized by data range)."""
    y = np.asarray(y_true).ravel()
    lo = np.asarray(lo).ravel()
    hi = np.asarray(hi).ravel()
    rng = y.max() - y.min() + 1e-12
    return float(np.mean((hi - lo) / rng))


def crps_normal(y_true, mu, sigma):
    """
    Continuous ranked probability score for a normal predictive
    distribution with parameters (mu, sigma) — closed form:
        CRPS = sigma * [ z * (2*Phi(z) - 1) + 2*phi(z) - 1/sqrt(pi) ]
    where z = (y - mu) / sigma.
    """
    y = np.asarray(y_true, dtype=np.float64).ravel()
    mu = np.asarray(mu, dtype=np.float64).ravel()
    sigma = np.asarray(sigma, dtype=np.float64).ravel()
    sigma = np.clip(sigma, 1e-4, None)
    z = (y - mu) / sigma
    crps = sigma * (z * (2.0 * _normal_cdf(z) - 1.0) +
                    2.0 * _normal_pdf(z) - 1.0 / np.sqrt(np.pi))
    return float(np.mean(crps))


def winkler(y_true, lo, hi, alpha=0.80):
    """
    Winkler score for the (1 - alpha) prediction interval:
        width if covered, else width + 2 * deviation / (1 - alpha).
    """
    y = np.asarray(y_true).ravel()
    lo = np.asarray(lo).ravel()
    hi = np.asarray(hi).ravel()
    width = hi - lo
    below = y < lo
    above = y > hi
    pen = np.zeros_like(y)
    pen[below] = 2.0 * (lo[below] - y[below]) / (1.0 - alpha)
    pen[above] = 2.0 * (y[above] - hi[above]) / (1.0 - alpha)
    return float(np.mean(width + pen))


# ---------------------------------------------------------------------- #
# Aggregate
# ---------------------------------------------------------------------- #
def evaluate_probabilistic(y_true, p10, p50, p90, alpha=0.80):
    """All probabilistic metrics from the P10/P50/P90 outputs."""
    mu = (np.asarray(p10) + np.asarray(p90)) / 2.0
    sigma = (np.asarray(p90) - np.asarray(p10)) / (2.0 * _Z90)
    return dict(
        picp=picp(y_true, p10, p90),
        pinaw=pinaw(y_true, p10, p90),
        crps=crps_normal(y_true, mu, sigma),
        winkler=winkler(y_true, p10, p90, alpha=alpha),
    )


def evaluate_all(y_true, p10, p50, p90, alpha=0.80):
    """Complete evaluation bundle used by scripts/03_evaluate.py."""
    y = np.asarray(y_true).ravel()
    out = {"rmse": rmse(y, p50.ravel()), "mae": mae(y, p50.ravel())}
    out.update(extreme_metrics(y, p50.ravel()))
    out.update(evaluate_probabilistic(y, p10.ravel(), p50.ravel(),
                                      p90.ravel(), alpha))
    return out


def summarize_runs(list_of_dicts):
    """mean +/- std over independent runs."""
    keys = list_of_dicts[0].keys()
    out = {}
    for k in keys:
        vals = np.array([d[k] for d in list_of_dicts])
        out[k] = (float(vals.mean()), float(vals.std()))
    return out
