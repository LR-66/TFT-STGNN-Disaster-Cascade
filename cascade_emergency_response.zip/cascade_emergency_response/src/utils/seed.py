# -*- coding: utf-8 -*-
"""Deterministic seeding utilities shared by every stage of the pipeline."""
import os
import random

import numpy as np


def set_seed(seed):
    """Fix every random source (numpy, python, torch) for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
    except ImportError:
        pass
    os.environ["PYTHONHASHSEED"] = str(seed)


def new_rng(seed):
    """Create an independent numpy random generator for reproducible data gen."""
    return np.random.RandomState(seed)
