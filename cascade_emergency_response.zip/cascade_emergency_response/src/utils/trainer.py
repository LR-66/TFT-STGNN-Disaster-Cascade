# -*- coding: utf-8 -*-
"""
Shared training / prediction helpers used by all scripts.

  * train_model      : generic Adam loop with early stopping (patience 10,
                       epochs 100, batch 64 — the paper's fixed setup);
  * predict_loader   : returns (y_true, p10, p50, p90) for quantile models;
  * predict_loader_point: returns point predictions (baselines) and performs
                       the paper's post-hoc interval calibration from
                       validation-set residuals (Section 4.1: "for baseline
                       models that produce only point forecasts, we estimate
                       prediction intervals via quantile regression applied to
                       their outputs under identical settings").
"""
from __future__ import division

import numpy as np
import torch

from config import config as C
from src.utils.seed import set_seed


def resolve_device():
    if torch.cuda.is_available():
        return "cuda"
    # use all available CPU cores for torch (older installs default lower)
    try:
        import os as _os
        n = _os.cpu_count() or 4
        if torch.get_num_threads() < n:
            torch.set_num_threads(n)
    except Exception:
        pass
    return "cpu"


def train_model(model, train_loader, val_loader, epochs=None, lr=None,
                seed=None, device=None, verbose=True, loss_fn=None):
    """Generic training loop. Returns (model, history)."""
    epochs = epochs if epochs is not None else C.TRAIN["epochs"]
    lr = lr if lr is not None else C.TRAIN["learning_rate"]
    seed = seed if seed is not None else C.SEED_MODEL
    device = device or resolve_device()

    set_seed(seed)
    model = model.to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    patience = C.TRAIN["early_stop_patience"]

    best_val = float("inf")
    best_state = None
    no_improve = 0
    history = []

    for epoch in range(1, epochs + 1):
        model.train()
        train_loss = 0.0
        n_batch = 0
        for batch in train_loader:
            batch = _to_device(batch, device)
            optimizer.zero_grad()
            if loss_fn is not None:
                loss = loss_fn(model, batch)
            else:
                loss = model.loss(batch)
            loss.backward()
            optimizer.step()
            train_loss += float(loss.item())
            n_batch += 1

        model.eval()
        val_loss = 0.0
        n_v = 0
        with torch.no_grad():
            for batch in val_loader:
                batch = _to_device(batch, device)
                if loss_fn is not None:
                    loss = loss_fn(model, batch)
                else:
                    loss = model.loss(batch)
                val_loss += float(loss.item())
                n_v += 1
        val_loss = val_loss / max(1, n_v)
        train_loss = train_loss / max(1, n_batch)

        history.append((train_loss, val_loss))
        if verbose and (epoch % 5 == 0 or epoch == 1):
            print("  epoch %3d | train loss %.4f | val loss %.4f"
                  % (epoch, train_loss, val_loss))

        if val_loss < best_val - 1e-5:
            best_val = val_loss
            best_state = {k: v.clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= patience:
                if verbose:
                    print("  early stopping at epoch %d (best val %.4f)"
                          % (epoch, best_val))
                break

    if best_state is not None:
        model.load_state_dict(best_state)
    return model, history


def predict_loader(model, loader, device=None):
    """Collect (y_true, p10, p50, p90) for a quantile-output model."""
    device = device or resolve_device()
    model = model.to(device).eval()
    ys, p10s, p50s, p90s = [], [], [], []
    with torch.no_grad():
        for batch in loader:
            x, s, a, y = _to_device(batch, device)
            out = model(x, s, a)
            pred = out["pred"]                       # (B, N, Q)
            ys.append(y.cpu().numpy())
            p10s.append(pred[..., 0].cpu().numpy())
            p50s.append(pred[..., 1].cpu().numpy())
            p90s.append(pred[..., 2].cpu().numpy())
    return (np.concatenate(ys).ravel(), np.concatenate(p10s).ravel(),
            np.concatenate(p50s).ravel(), np.concatenate(p90s).ravel())


def predict_loader_point(model, loader, val_loader=None, device=None):
    """
    Point predictions for baselines plus post-hoc interval calibration:
    residual quantiles (P10/P90) computed on the validation set are added to
    the test predictions.
    """
    device = device or resolve_device()
    model = model.to(device).eval()
    ys, preds = [], []
    with torch.no_grad():
        for batch in loader:
            x, s, a, y = _to_device(batch, device)
            p = model(x, s, a)
            if isinstance(p, dict):
                p = p["pred"]
            preds.append(p.cpu().numpy())
            ys.append(y.cpu().numpy())
    y_all = np.concatenate(ys).ravel()
    p_all = np.concatenate(preds).ravel()

    lo = hi = p_all
    if val_loader is not None:
        ys_v, ps_v = [], []
        with torch.no_grad():
            for batch in val_loader:
                x, s, a, y = _to_device(batch, device)
                p = model(x, s, a)
                if isinstance(p, dict):
                    p = p["pred"]
                ps_v.append(p.cpu().numpy())
                ys_v.append(y.cpu().numpy())
        resid = np.concatenate(ys_v).ravel() - np.concatenate(ps_v).ravel()
        q10, q90 = np.percentile(resid, [10, 90])
        lo = p_all + q10
        hi = p_all + q90
    return y_all, lo, p_all, hi


def _to_device(batch, device):
    return tuple(t.to(device) for t in batch)
