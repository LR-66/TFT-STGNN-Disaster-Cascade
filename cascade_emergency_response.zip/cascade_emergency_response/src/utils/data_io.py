# -*- coding: utf-8 -*-
"""
Data IO helpers shared by the numbered scripts: load the generated npz
archive, apply the preprocessing pipeline and build the three DataLoaders.
"""
from __future__ import division

import numpy as np

from config import config as C
from src.preprocessing.dataset import build_loaders
from src.preprocessing.transforms import Preprocessor
from src.simulation import static_attributes as SA


def load_and_prepare(data_dir=None, batch_size=None, lookback=None,
                     horizon=None, device="cpu"):
    """
    Returns (train_loader, val_loader, test_loader, meta) where meta carries
    static, adj, region_type and the y-scaling info.
    """
    data_dir = data_dir or C.DATA_DIR
    batch_size = batch_size if batch_size is not None else C.TRAIN["batch_size"]
    lookback = lookback if lookback is not None else 24
    horizon = horizon if horizon is not None else C.SIM["horizon"]

    z = np.load(data_dir + "/dataset.npz")
    feat = C.DYNAMIC_FEATURES
    x = np.stack([z[f] for f in feat], axis=-1)          # (T, N, C)
    y = z["riri"]                                        # (T, N)
    static = z["static_matrix"]                          # (N, D_s)
    adj = z["w_geo"]                                     # (N, N)

    # region type for grouped Z-score (rebuilt from static features)
    # static features are standardized; region type is the one-hot tail
    rt = static[:, -3:].argmax(axis=1).astype(int)

    pp = Preprocessor()
    # fit statistics on the training part only (no leakage)
    tr_end = int(x.shape[0] * (1.0 - C.PREPROCESS["val_frac"] -
                               C.PREPROCESS["test_frac"]))
    _ = pp.fit(x[:tr_end], rt)
    x_t = pp.transform(x, rt)

    train_loader, val_loader, test_loader = build_loaders(
        x_t, y, static, adj, batch_size=batch_size)
    meta = dict(static=static, adj=adj, region_type=rt, x_std=x_t, y=y,
                preprocessor=pp)
    return train_loader, val_loader, test_loader, meta
