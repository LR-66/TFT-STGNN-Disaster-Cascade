# -*- coding: utf-8 -*-
"""
Step 06: ablation study (Section 4.6, Table 6) — marginal contribution of
each component:
  * w/o TFT    : ST-GNN only (temporal input projected directly to nodes)
  * w/o ST-GNN : TFT only (no spatial module)
  * w/o Quantile: deterministic MSE point estimation (no probabilistic
                  constraints in scheduling)
Five runs per ablation are averaged (as in the paper).

Usage:
    python scripts/06_ablation.py [--epochs 20] [--runs 3]
"""
from __future__ import division

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import torch
import torch.nn as nn

from config import config as C
from src.evaluation.metrics import evaluate_all
from src.models.tft_stgnn import TFTSTGNN
from src.utils.data_io import load_and_prepare
from src.utils.trainer import predict_loader, resolve_device, train_model


class _NoTFT(nn.Module):
    """ST-GNN only: temporal covariates collapsed by mean pooling."""

    def __init__(self, n_nodes, d_in, d_hidden=128):
        super(_NoTFT, self).__init__()
        self.proj = nn.Sequential(nn.Linear(d_in, d_hidden), nn.ReLU())
        from src.models.stgnn import STGNN
        self.stgnn = STGNN(n_nodes, d_hidden=d_hidden)
        self.head = nn.Linear(d_hidden, 3)

    def forward(self, x, s, a):
        b, t, n, c = x.size()
        h = self.proj(x.mean(dim=1))                    # (B, N, d)
        ctx = h.mean(dim=1)
        h_s, lam = self.stgnn(h, ctx, a)
        return dict(pred=self.head(h_s))

    def loss(self, batch):
        x, s, a, y = batch
        from src.models.tft import quantile_loss
        return quantile_loss(y, self.forward(x, s, a)["pred"])


class _NoSTGNN(nn.Module):
    """TFT only: temporal encoder + head (no spatial module)."""

    def __init__(self, n_nodes, d_in, d_hidden=128):
        super(_NoSTGNN, self).__init__()
        from src.models.tft import TFTEncoder
        self.tft = TFTEncoder(d_in=d_in, d_hidden=d_hidden, n_static=7)
        self.head = nn.Linear(d_hidden, 3)

    def forward(self, x, s, a):
        h_t, ctx, attn, var = self.tft(x, s)
        return dict(pred=self.head(h_t))

    def loss(self, batch):
        x, s, a, y = batch
        from src.models.tft import quantile_loss
        return quantile_loss(y, self.forward(x, s, a)["pred"])


class _NoQuantile(nn.Module):
    """TFT-ST-GNN with deterministic MSE head (no quantile outputs)."""

    def __init__(self, n_nodes, d_in=7, d_hidden=128):
        super(_NoQuantile, self).__init__()
        self.base = TFTSTGNN(n_nodes, d_in=d_in, d_hidden=d_hidden,
                             quantiles=[0.5])
        self.head_mse = nn.Linear(d_hidden, 1)

    def forward(self, x, s, a):
        out = self.base.tft(x, s)
        h_t, ctx = out[0], out[1]
        h_s, lam = self.base.stgnn(h_t, ctx, a)
        fused = self.base.fusion(h_t, h_s)
        p = self.head_mse(fused).squeeze(-1)             # (B, N)
        # treat the point estimate as P50 with degenerate P10/P90
        return dict(pred=torch.stack([p, p, p], dim=-1))

    def loss(self, batch):
        x, s, a, y = batch
        p = self.forward(x, s, a)["pred"][..., 1]
        return torch.mean((p - y) ** 2)


ABLATIONS = {
    "w/o TFT": _NoTFT,
    "w/o ST-GNN": _NoSTGNN,
    "w/o Quantile": _NoQuantile,
}


def main():
    ap = argparse.ArgumentParser(description="Ablation study")
    ap.add_argument("--epochs", type=int, default=20)
    ap.add_argument("--runs", type=int, default=3)
    args = ap.parse_args()

    device = resolve_device()
    train_loader, val_loader, test_loader, meta = load_and_prepare()
    n_nodes = meta["adj"].shape[0]
    d_in = len(C.DYNAMIC_FEATURES)

    results = {}
    for name, factory in ABLATIONS.items():
        run_metrics = []
        for run in range(args.runs):
            seed = [C.SEED_MODEL, C.SEED_BASELINE, C.SEED_EXTRA][
                run % 3]
            print("\n=== Ablation '%s' run %d (seed %d) ==="
                  % (name, run + 1, seed))
            model = factory(n_nodes, d_in)
            train_model(model, train_loader, val_loader, epochs=args.epochs,
                        seed=seed, device=device)
            y_true, p10, p50, p90 = predict_loader(model, test_loader, device)
            run_metrics.append(evaluate_all(y_true, p10, p50, p90))
        mean = {k: float(np.mean([m[k] for m in run_metrics]))
                for k in run_metrics[0]}
        std = {k: float(np.std([m[k] for m in run_metrics]))
               for k in run_metrics[0]}
        results[name] = {"mean": mean, "std": std}
        print("  %-10s RMSE %.4f +/- %.4f | F1 %.3f | PICP %.3f"
              % (name, mean["rmse"], std["rmse"], mean["f1"], mean["picp"]))

    os.makedirs(C.RESULT_DIR, exist_ok=True)
    with open(os.path.join(C.RESULT_DIR, "ablation_metrics.json"), "w") as f:
        json.dump(results, f, indent=2)
    print("\n==> ablation results saved to outputs/results/ablation_metrics.json")


if __name__ == "__main__":
    main()
