# -*- coding: utf-8 -*-
"""
Step 01: generate the multi-agent simulation dataset and export CSV files.

Usage:
    python scripts/01_generate_data.py [--nodes 50] [--hours 10000]
                                       [--data_dir data]
"""
from __future__ import division

import argparse
import os
import sys

# allow running from the project root or from scripts/
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import config as C
from src.simulation.data_generator import generate_dataset


def main():
    ap = argparse.ArgumentParser(description="Generate the cascade dataset")
    ap.add_argument("--nodes", type=int, default=C.SIM["num_nodes"])
    ap.add_argument("--hours", type=int, default=C.SIM["num_hours"])
    ap.add_argument("--data_dir", type=str, default=C.DATA_DIR)
    ap.add_argument("--seed", type=int, default=C.SEED_DATA)
    args = ap.parse_args()

    print("==> Generating dataset: %d nodes x %d hours (seed %d)"
          % (args.nodes, args.hours, args.seed))
    res = generate_dataset(num_nodes=args.nodes, num_hours=args.hours,
                           data_dir=args.data_dir, seed=args.seed)
    print("==> Files written:")
    for k, p in res["files"].items():
        print("     %-10s %s" % (k, p))


if __name__ == "__main__":
    main()
