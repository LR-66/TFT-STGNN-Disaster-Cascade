# -*- coding: utf-8 -*-
"""
Step 03: evaluate the trained model on the test set and compare every metric
with the values reported in the paper (Section 4).

Usage:
    python scripts/03_evaluate.py [--model outputs/models/tft_stgnn.pt]
"""
from __future__ import division

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch

from config import config as C
from src.evaluation.metrics import evaluate_all
from src.models.tft_stgnn import TFTSTGNN
from src.utils.data_io import load_and_prepare
from src.utils.trainer import predict_loader, resolve_device

# paper-reported reference values (Section 4, Tables 2 / Figure 5-6)
PAPER_REPORTED = dict(
    rmse=0.071, mae=0.052, recall=0.97, precision=0.95, f1=0.96,
    picp=0.795, pinaw=0.182, crps=0.068, winkler=0.241,
)


def main():
    ap = argparse.ArgumentParser(description="Evaluate TFT-ST-GNN on test set")
    ap.add_argument("--model", type=str,
                    default=os.path.join(C.MODEL_DIR, "tft_stgnn.pt"))
    ap.add_argument("--out", type=str,
                    default=os.path.join(C.RESULT_DIR, "metrics.json"))
    args = ap.parse_args()

    device = resolve_device()
    train_loader, val_loader, test_loader, meta = load_and_prepare()
    n_nodes = meta["adj"].shape[0]

    model = TFTSTGNN(n_nodes=n_nodes)
    model.load_state_dict(torch.load(args.model, map_location=device))

    y_true, p10, p50, p90 = predict_loader(model, test_loader, device)
    metrics = evaluate_all(y_true, p10, p50, p90)

    print("\n=== Test-set metrics vs paper-reported values ===")
    rows = [("RMSE", metrics["rmse"], PAPER_REPORTED["rmse"]),
            ("MAE", metrics["mae"], PAPER_REPORTED["mae"]),
            ("Recall", metrics["recall"], PAPER_REPORTED["recall"]),
            ("Precision", metrics["precision"], PAPER_REPORTED["precision"]),
            ("F1", metrics["f1"], PAPER_REPORTED["f1"]),
            ("PICP", metrics["picp"], PAPER_REPORTED["picp"]),
            ("PINAW", metrics["pinaw"], PAPER_REPORTED["pinaw"]),
            ("CRPS", metrics["crps"], PAPER_REPORTED["crps"]),
            ("Winkler", metrics["winkler"], PAPER_REPORTED["winkler"])]
    for name, got, ref in rows:
        flag = "OK" if abs(got - ref) <= max(0.05, 0.3 * ref) else "DIFF"
        print("  %-9s  got %.4f | paper %.4f  [%s]" % (name, got, ref, flag))

    metrics["paper_reported"] = PAPER_REPORTED
    metrics["n_test_samples"] = int(len(y_true))
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        json.dump(metrics, f, indent=2)
    print("\n==> metrics saved to", args.out)


if __name__ == "__main__":
    main()
