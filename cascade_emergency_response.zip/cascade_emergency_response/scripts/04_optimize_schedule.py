# -*- coding: utf-8 -*-
"""
Step 04: emergency resource scheduling with the trained model's quantile
predictions (Section 2.4 / 4.4).

Writes:
  * outputs/schedules/plan.csv          — dispatch plan
  * outputs/schedules/lp/scheduling_model.lp — optimization model (LP format)
  * outputs/results/schedule_metrics.json — fulfillment / on-time / response
    time, plus the robustness across data-missing rates 5 % - 40 % (Section 4.5)

Usage:
    python scripts/04_optimize_schedule.py [--model outputs/models/tft_stgnn.pt]
"""
from __future__ import division

import argparse
import csv
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import torch

from config import config as C
from src.models.tft_stgnn import TFTSTGNN
from src.optimization.dispatch_sim import robustness_across_missing, \
    simulate_dispatch
from src.optimization.emergency_optimizer import solve_schedule
from src.utils.data_io import load_and_prepare
from src.utils.trainer import predict_loader, resolve_device


def main():
    ap = argparse.ArgumentParser(description="Emergency scheduling")
    ap.add_argument("--model", type=str,
                    default=os.path.join(C.MODEL_DIR, "tft_stgnn.pt"))
    args = ap.parse_args()

    device = resolve_device()
    train_loader, val_loader, test_loader, meta = load_and_prepare()
    n_nodes = meta["adj"].shape[0]

    model = TFTSTGNN(n_nodes=n_nodes)
    model.load_state_dict(torch.load(args.model, map_location=device))
    y_true, p10, p50, p90 = predict_loader(model, test_loader, device)

    # one representative scheduling decision per region (mean risk over
    # samples) — same structure as the per-timestamp decision loop
    n = n_nodes
    mean_risk = np.clip(np.mean(p50.reshape(-1, n), axis=0), 0.0, 1.0)
    mean_p10 = np.clip(np.mean(p10.reshape(-1, n), axis=0), 0.0, 1.0)
    mean_p90 = np.clip(np.mean(p90.reshape(-1, n), axis=0), 0.0, 1.0)

    dist = 1.0 / (np.asarray(meta["adj"]) + 1e-6)
    dist_km = np.clip(dist, 1.0, 600.0).mean(axis=1)

    res = solve_schedule(mean_risk, mean_p10, mean_risk, mean_p90, dist_km)
    demand_true = mean_risk * C.OPT["demand_base"]
    disp = simulate_dispatch(res["plan"], demand_true, dist_km)
    disp.update(solver=res["solver"], solve_time=res["solve_time"],
                lp_file=res["lp_file"])

    print("\n=== Emergency scheduling (Section 4.4) ===")
    print("  solver         : %s" % res["solver"])
    print("  solve time     : %.3f s" % res["solve_time"])
    print("  fulfillment    : %.3f" % disp["fulfillment_rate"])
    print("  on-time rate   : %.3f" % disp["on_time_rate"])
    print("  response time  : %.2f h" % disp["response_time_h"])
    print("  LP model       : %s" % res["lp_file"])

    # plan CSV
    os.makedirs(C.SCHEDULE_DIR, exist_ok=True)
    with open(os.path.join(C.SCHEDULE_DIR, "plan.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["region", "resource_type", "amount", "risk", "demand"])
        for (i, r), amt in sorted(res["plan"].items()):
            w.writerow([i, r, amt, round(float(mean_risk[i]), 4),
                        round(float(demand_true[i]), 2)])

    # robustness across missing data rates (Section 4.5)
    robust = robustness_across_missing(mean_risk, dist_km)
    print("\n=== Scheduling robustness vs data missing rate (Section 4.5) ===")
    for frac, m in robust.items():
        print("  missing %2d%% : fulfillment %.3f | on-time %.3f | solve %.3fs"
              % (int(frac * 100), m["fulfillment_rate"], m["on_time_rate"],
                 m["solve_time"]))

    disp["robustness"] = robust
    with open(os.path.join(C.RESULT_DIR, "schedule_metrics.json"), "w") as f:
        json.dump(disp, f, indent=2)
    print("\n==> schedule results saved to outputs/results/schedule_metrics.json")


if __name__ == "__main__":
    main()
