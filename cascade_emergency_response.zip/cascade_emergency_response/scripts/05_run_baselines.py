# -*- coding: utf-8 -*-
"""
Step 05: train and evaluate the five baselines (Section 3.2.1): PatchTST,
Informer, DCRNN, Graph WaveNet, AGCRN. Intervals for point-forecast baselines
are calibrated from validation residuals (Section 4.1 procedure).

Usage:
    python scripts/05_run_baselines.py [--epochs 30]
"""
from __future__ import division

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch

from config import config as C
from src.baselines.patchtst import PatchTST
from src.baselines.informer import Informer
from src.baselines.dcrnn import DCRNN
from src.baselines.graphwavenet import GraphWaveNet
from src.baselines.agcrn import AGCRN
from src.evaluation.metrics import evaluate_all
from src.utils.data_io import load_and_prepare
from src.utils.trainer import predict_loader_point, resolve_device, train_model

FACTORIES = {
    "patchtst": lambda n, d: PatchTST(d_in=d),
    "informer": lambda n, d: Informer(d_in=d),
    "dcrnn": lambda n, d: DCRNN(d_in=d),
    "graphwavenet": lambda n, d: GraphWaveNet(n_nodes=n, d_in=d),
    "agcrn": lambda n, d: AGCRN(n_nodes=n, d_in=d),
}


def _mse_loss(model, batch):
    x, s, a, y = batch
    p = model(x, s, a)
    if isinstance(p, dict):
        p = p["pred"]
    return torch.mean((p - y) ** 2)


def main():
    ap = argparse.ArgumentParser(description="Run all baselines")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--names", type=str, default=",".join(FACTORIES.keys()),
                    help="comma-separated subset of baselines")
    args = ap.parse_args()

    device = resolve_device()
    train_loader, val_loader, test_loader, meta = load_and_prepare()
    n_nodes = meta["adj"].shape[0]
    d_in = len(C.DYNAMIC_FEATURES)

    results = {}
    for name in [s.strip() for s in args.names.split(",") if s.strip()]:
        print("\n=== Baseline: %s ===" % name)
        model = FACTORIES[name](n_nodes, d_in)
        train_model(model, train_loader, val_loader, epochs=args.epochs,
                    device=device, loss_fn=_mse_loss)
        y_true, lo, p50, hi = predict_loader_point(model, test_loader,
                                                   val_loader, device)
        m = evaluate_all(y_true, lo, p50, hi)
        results[name] = m
        print("  RMSE %.4f | MAE %.4f | Recall %.3f | F1 %.3f | PICP %.3f"
              % (m["rmse"], m["mae"], m["recall"], m["f1"], m["picp"]))

    os.makedirs(C.RESULT_DIR, exist_ok=True)
    with open(os.path.join(C.RESULT_DIR, "baselines_metrics.json"), "w") as f:
        json.dump(results, f, indent=2)
    print("\n==> baselines metrics saved to outputs/results/baselines_metrics.json")


if __name__ == "__main__":
    main()
