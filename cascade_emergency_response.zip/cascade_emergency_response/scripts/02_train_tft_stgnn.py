# -*- coding: utf-8 -*-
"""
Step 02: train the joint TFT-ST-GNN model (Section 3.2.1 hyperparameters:
learning rate 0.001, batch size 64, Adam, 100 epochs, early-stop patience 10,
TFT hidden 128 / 4 heads; ST-GNN 2 conv layers, initial adaptive weight 0.5).

Usage:
    python scripts/02_train_tft_stgnn.py [--epochs 100] [--nodes 50]
"""
from __future__ import division

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import torch

from config import config as C
from src.models.tft_stgnn import TFTSTGNN
from src.utils.data_io import load_and_prepare
from src.utils.trainer import resolve_device, train_model


def main():
    ap = argparse.ArgumentParser(description="Train TFT-ST-GNN")
    ap.add_argument("--epochs", type=int, default=C.TRAIN["epochs"])
    ap.add_argument("--lr", type=float, default=C.TRAIN["learning_rate"])
    ap.add_argument("--batch_size", type=int, default=C.TRAIN["batch_size"])
    ap.add_argument("--seed", type=int, default=C.SEED_MODEL)
    ap.add_argument("--out", type=str,
                    default=os.path.join(C.MODEL_DIR, "tft_stgnn.pt"))
    args = ap.parse_args()

    device = resolve_device()
    print("==> device:", device)
    train_loader, val_loader, test_loader, meta = load_and_prepare(
        batch_size=args.batch_size)
    n_nodes = meta["adj"].shape[0]

    model = TFTSTGNN(n_nodes=n_nodes)
    print("==> model parameters: %.1f K"
          % (sum(p.numel() for p in model.parameters()) / 1e3))

    model, history = train_model(model, train_loader, val_loader,
                                 epochs=args.epochs, lr=args.lr,
                                 seed=args.seed, device=device)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    torch.save(model.state_dict(), args.out)
    os.makedirs(C.RESULT_DIR, exist_ok=True)
    with open(os.path.join(C.RESULT_DIR, "train_history.json"), "w") as f:
        json.dump({"history": history, "seed": args.seed}, f, indent=2)
    print("==> model saved to", args.out)


if __name__ == "__main__":
    main()
