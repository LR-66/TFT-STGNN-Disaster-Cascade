# -*- coding: utf-8 -*-
"""
Central hyperparameter configuration of the paper

    "Cross-Regional Hydro-Meteorological Cascade Propagation Modeling and
     Emergency Response Optimization Using Temporal Fusion Transformer and
     Spatio-Temporal GNN"  (Longkai Chen)

Every value below follows the paper (Section 3 and the hyperparameters stated
in Section 3.2.1), so that the replication package is fully reproducible with
the fixed random seeds 42 / 123 / 456 / 789 / 101112.
"""

# --------------------------------------------------------------------------- #
# Random seeds (Section 3.1 / 3.2.1 of the paper)
# --------------------------------------------------------------------------- #
SEED_DATA = 42          # data generation
SEED_SPLIT = 123        # train / validation / test split
SEED_MODEL = 456        # model parameter initialization
SEED_BASELINE = 789     # baseline reproducibility
SEED_EXTRA = 101112     # extra independent runs (used for 3-run averages)

# --------------------------------------------------------------------------- #
# Simulation / dataset (Section 3.1)
# --------------------------------------------------------------------------- #
SIM = dict(
    num_nodes=50,               # heterogeneous region nodes (paper: 50 - 500)
    num_hours=10000,            # hourly multivariate time series length
    horizon=24,                 # prediction horizon in hours (24h-ahead)
    time_granularity_h=1.0,     # one time step = 1 hour

    # cascade trigger condition: disaster in region A requires local intensity
    # above the 80th percentile and physical connectivity with B
    trigger_percentile=0.80,
    # propagation delay uniformly sampled from [6, 72] hours,
    # inversely proportional to primary-disaster intensity
    delay_min_h=6.0,
    delay_max_h=72.0,
    # edge connectivity: geographic distance <= 50 km or direct road link
    distance_threshold_km=50.0,
    road_link_prob=0.35,        # OSM-style road connectivity probability
)

# RIRI target composition (Eq. 12): weights calibrated from EM-DAT
RIRI_WEIGHTS = dict(hazard=0.5, infrastructure=0.3, population=0.2)

# Static covariates per region (sampled from public-data-calibrated
# distributions; Table 1 of the paper)
STATIC_FEATURES = dict(
    elevation_m=dict(mean=180.0, std=120.0, clip=(0, 3000)),          # SRTM DEM
    population_density=dict(mu=5.2, sigma=1.1, clip=(1, 4000)),       # WorldPop, log-normal
    road_redundancy=dict(mean=0.55, std=0.20, clip=(0.05, 1.0)),      # OSM road network redundancy
    infrastructure_capacity=dict(mu=1.1, sigma=0.6, clip=(0.2, 20.0)),  # log-normal
)

# Dynamic covariate list (Table 1: continuous meteorological series and
# discrete public-opinion indicators)
CONTINUOUS_FEATURES = ["rainfall", "river_level", "wind_speed", "air_temp"]
DISCRETE_FEATURES = ["disaster_keyword_freq", "help_requests", "traffic_incidents"]
DYNAMIC_FEATURES = CONTINUOUS_FEATURES + DISCRETE_FEATURES

# Value ranges / distribution characteristics (Table 1)
COVARIATE_DIST = dict(
    rainfall=(0.0, 100.0),            # mm/h, right-skewed (gamma)
    river_level=(0.0, 10.0),          # m, seasonal fluctuations
    wind_speed=(0.0, 30.0),           # m/s, non-negative skewed
    air_temp=(0.0, 40.0),             # deg C, seasonal
    disaster_keyword_freq=(0, 5000),  # counts, over-dispersed
    help_requests=(0, 2000),          # counts
    traffic_incidents=(0, 300),       # counts
)

# --------------------------------------------------------------------------- #
# Preprocessing (Section 3.1 / 2.1)
# --------------------------------------------------------------------------- #
PREPROCESS = dict(
    detrend=True,           # detrending of continuous series
    log_stabilize=True,     # log-stabilization of skewed variables
    window_std=168,         # sliding window (hours) for standardization
    group_by_region=True,   # Z-score standardization grouped by region type
    val_frac=0.15,
    test_frac=0.15,
)

# --------------------------------------------------------------------------- #
# TFT module (Section 2.1 - 2.2)
# --------------------------------------------------------------------------- #
TFT = dict(
    hidden_size=128,        # TFT hidden dimension (paper: 128)
    num_heads=4,            # number of attention heads (paper: 4)
    dropout=0.1,
    quantiles=[0.10, 0.50, 0.90],   # P10 / P50 / P90 (80% interval)
    causal_conv_kernel=3,   # causal convolution kernel length (Eq. 6)
    num_layers=2,           # gated-residual / transformer layers
)

# --------------------------------------------------------------------------- #
# ST-GNN module (Section 2.3)
# --------------------------------------------------------------------------- #
STGNN = dict(
    graph_conv_layers=2,            # graph convolutional layers (paper: 2)
    hidden_size=128,                # node embedding dim (aligned with TFT)
    init_adaptive_weight=0.5,       # initial adaptive adjacency weight (paper)
    emb_dim=32,                     # node embedding dim for adjacency learning
    time_gate=True,                 # time-aware gating unit (Eq. 11)
)

# --------------------------------------------------------------------------- #
# Joint training (Section 3.2.1 - fixed across all experiments)
# --------------------------------------------------------------------------- #
TRAIN = dict(
    learning_rate=0.001,
    batch_size=64,
    optimizer="adam",
    epochs=100,
    early_stop_patience=10,
    num_runs=3,             # average over three independent runs
)

# --------------------------------------------------------------------------- #
# Baselines (Section 3.2.1 - configurations stated in the paper)
# --------------------------------------------------------------------------- #
BASELINES = dict(
    patchtst=dict(patch_len=24, d_model=256, n_heads=8, n_layers=3),
    informer=dict(prob_sparse_sampling=0.7, n_encoder_layers=4,
                  n_decoder_layers=4, d_model=128, conv_kernels=4),
    dcrnn=dict(diffusion_stride=2, gru_hidden=64, graph_conv_layers=2),
    graphwavenet=dict(dilated_layers=8, adaptive_emb_dim=16, kernel_width=2,
                      d_model=32),
    agcrn=dict(node_emb_dim=32, gru_units=2, hidden_size=64),
)

# --------------------------------------------------------------------------- #
# Integer programming scheduling (Section 2.4)
# --------------------------------------------------------------------------- #
OPT = dict(
    solver="gurobi",            # 'gurobi' if gurobipy importable else 'priority'
    gurobi_time_limit_s=60.0,   # Gurobi max solution time (paper)
    alpha=0.95,                 # confidence level of the chance constraint
    n_time_windows=4,           # piecewise-constant time windows (e.g., 6h)
    window_hours=6.0,
    gamma=0.3,                  # fairness trade-off coefficient (Eq. 14)
    coverage_weight=1.0,        # coverage coefficient in the objective
    delay_weight=1.0,
    total_supplies=100000.0,    # total available resource budget
    total_personnel=5000.0,
    capacity_supplies=20000.0,  # per-path capacity
    capacity_personnel=1000.0,
    damage_sensitivity=0.35,    # path-capacity degradation sensitivity (Eq. 15)
    demand_base=200.0,          # demand scale factor (demand ~ risk * scale)
    travel_time_km_h=40.0,      # convoy speed used to derive arrival windows
)

# Metrics configuration (Section 4.1)
METRICS = dict(
    nominal_coverage=0.80,      # P10-P90 -> nominal 80% interval
    extreme_quantile=0.90,      # risk intensity above historical 90th pct = positive
    missing_rates=[0.05, 0.10, 0.20, 0.30, 0.40],   # scheduling robustness
)

# --------------------------------------------------------------------------- #
# Paths (relative to project root)
# --------------------------------------------------------------------------- #
DATA_DIR = "data"
OUTPUT_DIR = "outputs"
MODEL_DIR = "outputs/models"
RESULT_DIR = "outputs/results"
SCHEDULE_DIR = "outputs/schedules"
LP_DIR = "outputs/schedules/lp"
